(() => {
  const THEME_STORAGE_KEY = "magister-pack-club-theme";
  const CUSTOM_MEMES_STORAGE_KEY = "magister-pack-club-custom-memes";
  const SAVED_THEMES_STORAGE_KEY = "magister-pack-club-saved-themes";
  const PRESET_FORMAT = "magister-pack-club-settings";
  const PRESET_VERSION = 1;
  const MAX_CUSTOM_MEME_DATA_URL_LENGTH = 120000;
  const MAX_SAVED_PRESETS = 4;
  const MAX_IMAGE_FILE_SIZE = 12 * 1024 * 1024;
  const MAX_PRESET_FILE_SIZE = 2 * 1024 * 1024;
  const THEMES = new Set(["stadion", "nacht", "teal"]);
  const DEFAULT_MEME_ASSETS = [
    "assets/meme-cat.png",
    "assets/memes/cat-container-1.jpg",
    "assets/memes/surprised-cat.jpg",
    "assets/memes/funny-cats.jpg",
    "assets/memes/cat-scratch.jpg",
    "assets/memes/should-i-stay-cat.jpg",
    "assets/memes/woaw-cat.jpg",
    "assets/memes/something-in-eye-cat.jpg",
    "assets/memes/serious-business-cat.jpg",
    "assets/memes/cat-fishing.jpg"
  ];
  const storage = globalThis.browser?.storage?.local || globalThis.chrome?.storage?.local;
  const storageChanges = globalThis.browser?.storage?.onChanged || globalThis.chrome?.storage?.onChanged;
  const runtime = globalThis.browser?.runtime || globalThis.chrome?.runtime;
  const defaultMemeUrls = DEFAULT_MEME_ASSETS.map((asset) => runtime?.getURL?.(asset) || "");
  const memeList = document.getElementById("meme-list");
  const presetList = document.getElementById("preset-list");
  const presetNameInput = document.getElementById("preset-name");
  const importFileInput = document.getElementById("import-file");
  let settings = { theme: "stadion", customMemes: {} };
  let savedPresets = [];
  let isReady = false;

  function showPage(pageName) {
    for (const page of document.querySelectorAll(".page")) {
      page.hidden = page.id !== `page-${pageName}`;
    }
    for (const tab of document.querySelectorAll(".tab")) {
      const active = tab.id === `tab-${pageName}`;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
    }
  }

  function setStatus(id, message, isError = false) {
    const status = document.getElementById(id);
    status.textContent = message;
    status.dataset.error = String(isError);
  }

  function setReady(ready, allowReset = false) {
    isReady = ready;
    for (const option of document.querySelectorAll(".theme-option")) {
      option.disabled = !ready;
    }
    for (const id of ["save-preset", "export-current", "import-trigger"]) {
      document.getElementById(id).disabled = !ready;
    }
    document.getElementById("reset-settings").disabled = !storage || !(ready || allowReset);
  }

  function reportError(statusId, pageName, message, error) {
    console.error("[Magister Pack Club] " + message, error);
    showPage(pageName);
    setStatus(statusId, message, true);
  }

  function isValidCustomMemes(value) {
    return value !== null
      && typeof value === "object"
      && !Array.isArray(value)
      && Object.entries(value).every(([rating, dataUrl]) =>
        (/^[1-9]$|^10$/).test(rating)
        && typeof dataUrl === "string"
        && dataUrl.length <= MAX_CUSTOM_MEME_DATA_URL_LENGTH
        && /^data:image\/(?:webp|png|jpeg);base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl));
  }

  function isValidSavedPresets(value) {
    return Array.isArray(value)
      && value.length <= MAX_SAVED_PRESETS
      && value.every((preset) =>
        preset
        && typeof preset.id === "string"
        && typeof preset.name === "string"
        && preset.name.trim().length > 0
        && preset.name.length <= 32
        && THEMES.has(preset.theme)
        && isValidCustomMemes(preset.customMemes));
  }

  function validatePresetDocument(documentValue) {
    if (!documentValue
      || documentValue.format !== PRESET_FORMAT
      || documentValue.version !== PRESET_VERSION
      || !documentValue.settings
      || !THEMES.has(documentValue.settings.theme)
      || !isValidCustomMemes(documentValue.settings.customMemes)) {
      throw new TypeError("Dit is geen geldige Magister Pack Club-preset.");
    }
    const name = typeof documentValue.name === "string" && documentValue.name.trim()
      ? documentValue.name.trim().slice(0, 32)
      : "Gedeelde preset";
    return {
      name,
      theme: documentValue.settings.theme,
      customMemes: { ...documentValue.settings.customMemes }
    };
  }

  function selectTheme(theme) {
    settings.theme = theme;
    for (const option of document.querySelectorAll(".theme-option")) {
      option.setAttribute("aria-pressed", String(option.dataset.theme === theme));
    }
  }

  function updateThemeOptions() {
    for (const option of document.querySelectorAll(".theme-option")) {
      option.setAttribute("aria-pressed", String(option.dataset.theme === settings.theme));
    }
  }

  function makeButton(text, className, handler) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = text;
    button.addEventListener("click", handler);
    return button;
  }

  function renderMemeList() {
    memeList.replaceChildren();
    for (let rating = 1; rating <= 10; rating += 1) {
      const row = document.createElement("div");
      row.className = "meme-row";
      const preview = document.createElement("img");
      preview.className = "meme-preview";
      preview.alt = "";
      preview.src = settings.customMemes[String(rating)] || defaultMemeUrls[rating - 1];
      const label = document.createElement("div");
      label.className = "meme-label";
      const title = document.createElement("strong");
      title.textContent = `Cijfer ${rating}`;
      const state = document.createElement("small");
      state.textContent = settings.customMemes[String(rating)] ? "Aangepast meme" : "Standaardmeme";
      label.append(title, state);
      const fileInput = document.createElement("input");
      fileInput.type = "file";
      fileInput.accept = "image/*";
      fileInput.className = "file-input";
      fileInput.setAttribute("aria-label", `Kies meme voor cijfer ${rating}`);
      const chooseButton = makeButton("Kies", "choose-meme", () => fileInput.click());
      chooseButton.setAttribute("aria-label", `Kies meme voor cijfer ${rating}`);
      const removeButton = makeButton("Herstel", "remove-meme", async () => {
        const nextMemes = { ...settings.customMemes };
        delete nextMemes[String(rating)];
        removeButton.disabled = true;
        try {
          await storage.set({ [CUSTOM_MEMES_STORAGE_KEY]: nextMemes });
          settings.customMemes = nextMemes;
          renderMemeList();
          setStatus("meme-status", `Standaardmeme voor cijfer ${rating} hersteld.`);
        } catch (error) {
          reportError("meme-status", "memes", "Meme kon niet worden hersteld.", error);
          removeButton.disabled = false;
        }
      });
      removeButton.setAttribute("aria-label", `Herstel standaardmeme voor cijfer ${rating}`);
      removeButton.disabled = !settings.customMemes[String(rating)] || !isReady;
      chooseButton.disabled = !isReady;
      fileInput.disabled = !isReady;
      fileInput.addEventListener("change", async () => {
        const file = fileInput.files?.[0];
        if (!file) return;
        chooseButton.disabled = true;
        fileInput.disabled = true;
        setStatus("meme-status", `Afbeelding voor cijfer ${rating} verwerken...`);
        try {
          const dataUrl = await encodeMemeImage(file);
          const nextMemes = { ...settings.customMemes, [String(rating)]: dataUrl };
          await storage.set({ [CUSTOM_MEMES_STORAGE_KEY]: nextMemes });
          settings.customMemes = nextMemes;
          renderMemeList();
          setStatus("meme-status", `Eigen meme voor cijfer ${rating} opgeslagen.`);
        } catch (error) {
          reportError("meme-status", "memes", "Afbeelding kon niet worden opgeslagen.", error);
          chooseButton.disabled = false;
          fileInput.disabled = false;
        }
      });
      row.append(preview, label, fileInput, chooseButton, removeButton);
      memeList.append(row);
    }
  }

  async function encodeMemeImage(file) {
    if (file.type && !file.type.startsWith("image/")) throw new TypeError("Kies een afbeeldingsbestand.");
    if (file.size > MAX_IMAGE_FILE_SIZE) throw new RangeError("De afbeelding is groter dan 12 MB.");
    const objectUrl = URL.createObjectURL(file);
    try {
      const image = new Image();
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = () => reject(new Error("De afbeelding kon niet worden gelezen."));
        image.src = objectUrl;
      });
      if (image.naturalWidth * image.naturalHeight > 40000000) {
        throw new RangeError("De afbeeldingsresolutie is te groot.");
      }
      const createDataUrl = (maximumDimension, quality) => {
        const scale = Math.min(1, maximumDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) throw new Error("De afbeelding kon niet worden verwerkt.");
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL("image/webp", quality);
      };
      let dataUrl = createDataUrl(420, 0.78);
      if (dataUrl.length > MAX_CUSTOM_MEME_DATA_URL_LENGTH) {
        dataUrl = createDataUrl(300, 0.58);
      }
      if (!/^data:image\/webp;base64,/.test(dataUrl)
        || dataUrl.length > MAX_CUSTOM_MEME_DATA_URL_LENGTH) {
        throw new RangeError("De afbeelding blijft na verkleinen te groot.");
      }
      return dataUrl;
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  }

  function makePresetDocument(preset) {
    return {
      format: PRESET_FORMAT,
      version: PRESET_VERSION,
      name: preset.name,
      settings: {
        theme: preset.theme,
        customMemes: { ...preset.customMemes }
      }
    };
  }

  function downloadPreset(preset) {
    const blob = new Blob([JSON.stringify(makePresetDocument(preset), null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const safeName = preset.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")
      || "magister-pack-club";
    link.href = url;
    link.download = `${safeName}.mpc-theme.json`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  function renderSavedPresets() {
    presetList.replaceChildren();
    if (!savedPresets.length) {
      const empty = document.createElement("p");
      empty.className = "preset-empty";
      empty.textContent = "Nog geen presets opgeslagen.";
      presetList.append(empty);
      return;
    }
    for (const preset of savedPresets) {
      const row = document.createElement("div");
      row.className = "preset-row";
      const name = document.createElement("span");
      name.className = "preset-name";
      name.title = preset.name;
      const dot = document.createElement("span");
      dot.className = "preset-color";
      const text = document.createElement("span");
      text.textContent = preset.name;
      name.append(dot, text);
      const loadButton = makeButton("Laad", "preset-load", async () => {
        try {
          await storage.set({
            [THEME_STORAGE_KEY]: preset.theme,
            [CUSTOM_MEMES_STORAGE_KEY]: { ...preset.customMemes }
          });
          settings = { theme: preset.theme, customMemes: { ...preset.customMemes } };
          updateThemeOptions();
          renderMemeList();
          setStatus("preset-status", `Preset '${preset.name}' geladen.`);
        } catch (error) {
          reportError("preset-status", "themes", "Preset kon niet worden geladen.", error);
        }
      });
      const shareButton = makeButton("Deel", "preset-share", () => {
        downloadPreset(preset);
        setStatus("preset-status", `Preset '${preset.name}' geëxporteerd.`);
      });
      const deleteButton = makeButton("×", "preset-delete", async () => {
        const nextPresets = savedPresets.filter((item) => item.id !== preset.id);
        deleteButton.disabled = true;
        try {
          await storage.set({ [SAVED_THEMES_STORAGE_KEY]: nextPresets });
          savedPresets = nextPresets;
          renderSavedPresets();
          setStatus("preset-status", `Preset '${preset.name}' verwijderd.`);
        } catch (error) {
          reportError("preset-status", "themes", "Preset kon niet worden verwijderd.", error);
        }
      });
      deleteButton.setAttribute("aria-label", `Verwijder preset ${preset.name}`);
      loadButton.disabled = !isReady;
      shareButton.disabled = !isReady;
      deleteButton.disabled = !isReady;
      row.append(name, loadButton, shareButton, deleteButton);
      presetList.append(row);
    }
  }

  async function saveCurrentPreset() {
    const name = presetNameInput.value.trim();
    if (!name) {
      setStatus("preset-status", "Vul eerst een naam in.", true);
      presetNameInput.focus();
      return;
    }
    if (savedPresets.length >= MAX_SAVED_PRESETS) {
      setStatus("preset-status", `Je kunt maximaal ${MAX_SAVED_PRESETS} presets bewaren.`, true);
      return;
    }
    const id = globalThis.crypto?.randomUUID?.()
      || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const preset = {
      id,
      name: name.slice(0, 32),
      theme: settings.theme,
      customMemes: { ...settings.customMemes }
    };
    const nextPresets = [...savedPresets, preset];
    const saveButton = document.getElementById("save-preset");
    saveButton.disabled = true;
    try {
      await storage.set({ [SAVED_THEMES_STORAGE_KEY]: nextPresets });
      savedPresets = nextPresets;
      presetNameInput.value = "";
      renderSavedPresets();
      setStatus("preset-status", `Preset '${preset.name}' opgeslagen.`);
    } catch (error) {
      reportError("preset-status", "themes", "Preset kon niet worden opgeslagen.", error);
    } finally {
      saveButton.disabled = false;
    }
  }

  async function importPresetFile(file) {
    if (file.size > MAX_PRESET_FILE_SIZE) {
      throw new RangeError("Het preset-bestand is groter dan 2 MB.");
    }
    const preset = validatePresetDocument(JSON.parse(await file.text()));
    await storage.set({
      [THEME_STORAGE_KEY]: preset.theme,
      [CUSTOM_MEMES_STORAGE_KEY]: preset.customMemes
    });
    settings = { theme: preset.theme, customMemes: preset.customMemes };
    updateThemeOptions();
    renderMemeList();
    setStatus("preset-status", `Preset '${preset.name}' ingeladen.`);
  }

  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => showPage(tab.id.slice(4)));
  }
  document.getElementById("choose-theme").addEventListener("click", () => showPage("theme"));
  document.getElementById("version").textContent = `v${runtime?.getManifest?.().version || "onbekend"}`;

  for (const option of document.querySelectorAll(".theme-option")) {
    option.addEventListener("click", async () => {
      const theme = option.dataset.theme;
      if (!storage || !isReady || !THEMES.has(theme)) {
        reportError("theme-status", "theme", "Instellingen zijn niet beschikbaar.", new Error("Extensieopslag ontbreekt."));
        return;
      }
      try {
        await storage.set({ [THEME_STORAGE_KEY]: theme });
        selectTheme(theme);
        setStatus("theme-status", "Thema opgeslagen.");
      } catch (error) {
        reportError("theme-status", "theme", "Thema kon niet worden opgeslagen.", error);
      }
    });
  }

  document.getElementById("save-preset").addEventListener("click", () => void saveCurrentPreset());
  presetNameInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") void saveCurrentPreset();
  });
  document.getElementById("export-current").addEventListener("click", () => {
    downloadPreset({ name: "Mijn instellingen", ...settings });
    setStatus("preset-status", "Huidige instellingen geëxporteerd.");
  });
  document.getElementById("import-trigger").addEventListener("click", () => importFileInput.click());
  importFileInput.addEventListener("change", async () => {
    const file = importFileInput.files?.[0];
    if (!file) return;
    try {
      await importPresetFile(file);
    } catch (error) {
      reportError("preset-status", "themes", "Preset-bestand kon niet worden ingeladen.", error);
    } finally {
      importFileInput.value = "";
    }
  });
  document.getElementById("reset-settings").addEventListener("click", async () => {
    const button = document.getElementById("reset-settings");
    if (!storage) return;
    button.disabled = true;
    try {
      await storage.remove([
        THEME_STORAGE_KEY,
        CUSTOM_MEMES_STORAGE_KEY,
        SAVED_THEMES_STORAGE_KEY
      ]);
      settings = { theme: "stadion", customMemes: {} };
      savedPresets = [];
      setReady(true);
      updateThemeOptions();
      renderMemeList();
      renderSavedPresets();
      setStatus("start-status", "Standaardinstellingen hersteld. Packs en voortgang zijn behouden.");
    } catch (error) {
      reportError("start-status", "start", "Instellingen konden niet worden hersteld.", error);
    } finally {
      button.disabled = false;
    }
  });

  storageChanges?.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    if (changes[THEME_STORAGE_KEY]) {
      const theme = changes[THEME_STORAGE_KEY].newValue;
      settings.theme = THEMES.has(theme) ? theme : "stadion";
      updateThemeOptions();
    }
    if (changes[CUSTOM_MEMES_STORAGE_KEY]) {
      const memes = changes[CUSTOM_MEMES_STORAGE_KEY].newValue;
      if (memes !== undefined && !isValidCustomMemes(memes)) {
        reportError("meme-status", "memes", "Opgeslagen memes hebben een ongeldig formaat.", new TypeError("Ongeldige meme-opslag."));
        return;
      }
      settings.customMemes = memes || {};
      renderMemeList();
    }
    if (changes[SAVED_THEMES_STORAGE_KEY]) {
      const presets = changes[SAVED_THEMES_STORAGE_KEY].newValue;
      if (presets !== undefined && !isValidSavedPresets(presets)) {
        reportError("preset-status", "themes", "Opgeslagen presets hebben een ongeldig formaat.", new TypeError("Ongeldige preset-opslag."));
        return;
      }
      savedPresets = presets || [];
      renderSavedPresets();
    }
  });

  async function initialize() {
    if (!storage) {
      reportError("start-status", "start", "Instellingen zijn niet beschikbaar.", new Error("Extensieopslag ontbreekt."));
      return;
    }
    try {
      const stored = await storage.get([
        THEME_STORAGE_KEY,
        CUSTOM_MEMES_STORAGE_KEY,
        SAVED_THEMES_STORAGE_KEY
      ]);
      const theme = stored[THEME_STORAGE_KEY];
      const memes = stored[CUSTOM_MEMES_STORAGE_KEY];
      const presets = stored[SAVED_THEMES_STORAGE_KEY];
      if (theme !== undefined && !THEMES.has(theme)) throw new TypeError("Opgeslagen thema is ongeldig.");
      if (memes !== undefined && !isValidCustomMemes(memes)) throw new TypeError("Opgeslagen memes zijn ongeldig.");
      if (presets !== undefined && !isValidSavedPresets(presets)) throw new TypeError("Opgeslagen presets zijn ongeldig.");
      settings = { theme: theme || "stadion", customMemes: memes || {} };
      savedPresets = presets || [];
      setReady(true);
      updateThemeOptions();
      renderMemeList();
      renderSavedPresets();
    } catch (error) {
      setReady(false, true);
      reportError("start-status", "start", "Instellingen konden niet worden geladen.", error);
    }
  }

  setReady(false);
  renderMemeList();
  renderSavedPresets();
  void initialize();
})();
