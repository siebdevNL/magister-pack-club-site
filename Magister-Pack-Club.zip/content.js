(() => {
  const ROOT_ID = "magister-pack-opener-root";
  const AUTO_OPEN_KEY = "magister-pack-opener-auto-open";
  const THEME_STORAGE_KEY = "magister-pack-club-theme";
  const CUSTOM_MEMES_STORAGE_KEY = "magister-pack-club-custom-memes";
  const THEMES = new Set(["stadion", "nacht", "teal"]);
  const extensionRuntime = globalThis.browser?.runtime || globalThis.chrome?.runtime;
  const extensionStorage = globalThis.browser?.storage?.local || globalThis.chrome?.storage?.local;
  const extensionStorageChanges = globalThis.browser?.storage?.onChanged
    || globalThis.chrome?.storage?.onChanged;
  const OPENED_GRADES_STORAGE_KEY = "magister-pack-opened-grade-ids";
  const CUSTOM_PACKS_STORAGE_KEY = "magister-pack-custom-packs";
  const MAX_CUSTOM_MEME_DATA_URL_LENGTH = 120000;
  const APP_VERSION = extensionRuntime?.getManifest?.().version || "onbekend";
  const MEME_ICON_URLS = [
    "assets/meme-cat.png",
    "assets/memes/cat-container-1.jpg",
    "assets/memes/surprised-cat.jpg",
    "assets/memes/funny-cats.jpg",
    "assets/memes/cat-scratch.jpg",
    "assets/memes/should-i-stay-cat.jpg",
    "assets/memes/woaw-cat.jpg",
    "assets/memes/something-in-eye-cat.jpg",
    "assets/memes/serious-business-cat.jpg",
    "assets/memes/cat-fishing.jpg"
  ].map((assetPath) => extensionRuntime?.getURL?.(assetPath)).filter(Boolean);
  if (document.getElementById(ROOT_ID)) return;

  function isGradesRoute() {
    const hashRoute = window.location.hash.slice(1)
      .split(/[?;]/, 1)[0]
      .replace(/^\/+/, "");
    return /^cijfers(?:\/|$)/i.test(hashRoute)
      || /\/cijfers(?:\/|$)/i.test(window.location.pathname);
  }

  const pendingAutoOpen = sessionStorage.getItem(AUTO_OPEN_KEY);
  if (pendingAutoOpen) {
    sessionStorage.removeItem(AUTO_OPEN_KEY);
    if (Date.now() - Number(pendingAutoOpen) < 15000) {
      window.setTimeout(openDashboard, 1000);
    }
  }

  const style = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .backdrop {
      position: fixed; inset: 0; z-index: 2147483647; display: block;
      background: #020806f5;
      color: #f7f7f2; font: 14px/1.45 system-ui,sans-serif;
    }
    .app {
      position: relative; width: 100%; height: 100%; overflow: auto;
      padding: clamp(18px,4vw,48px); background:
        conic-gradient(from 160deg at 0% 0%,transparent 0deg,#8eb9e00a 16deg,transparent 35deg),
        conic-gradient(from 200deg at 100% 0%,transparent 0deg,#8eb9e00a 16deg,transparent 35deg),
        radial-gradient(ellipse at 50% 105%,#4bbd6245,transparent 34%),
        radial-gradient(ellipse at 50% -8%,#37578d80,transparent 48%),
        radial-gradient(ellipse at 0% 39%,#ffdf8d18,transparent 23%),
        radial-gradient(ellipse at 100% 39%,#ffdf8d18,transparent 23%),
        repeating-linear-gradient(90deg,transparent 0 23px,#d8e6ff07 24px 25px),
        linear-gradient(180deg,#071222,#081322 56%,#06110c);
    }
    .app[data-theme="nacht"] {
      background:
        radial-gradient(ellipse at 50% 105%,#42557438,transparent 34%),
        radial-gradient(ellipse at 50% -8%,#19233a99,transparent 48%),
        repeating-linear-gradient(90deg,transparent 0 23px,#d8e6ff05 24px 25px),
        linear-gradient(180deg,#080b14,#101522 56%,#070910);
    }
    .app[data-theme="nacht"] .pack-area {
      background:
        radial-gradient(ellipse at 50% 86%,#777f9b36,transparent 26%),
        radial-gradient(ellipse at 50% 70%,#404c7033,transparent 42%),
        radial-gradient(ellipse at 50% 5%,#30354f99,transparent 55%),
        linear-gradient(180deg,#0b0e1a,#171a2a 53%,#090a12);
    }
    .app[data-theme="teal"] {
      background:
        radial-gradient(ellipse at 50% 105%,#20a98a35,transparent 34%),
        radial-gradient(ellipse at 50% -8%,#087e8090,transparent 48%),
        repeating-linear-gradient(90deg,transparent 0 23px,#d8e6ff07 24px 25px),
        linear-gradient(180deg,#07171b,#082326 56%,#061512);
    }
    .app[data-theme="teal"] .pack-area {
      background:
        radial-gradient(ellipse at 50% 86%,#36d5ae38,transparent 26%),
        radial-gradient(ellipse at 50% 70%,#15b8c235,transparent 42%),
        radial-gradient(ellipse at 50% 5%,#147f8c99,transparent 55%),
        linear-gradient(180deg,#071b25,#0b3038 53%,#071619);
    }
    button { font: inherit; }
    .close {
      position: absolute; top: 16px; right: 18px; width: 38px; height: 38px;
      border: 1px solid #ffffff30; border-radius: 50%; color: white;
      background: #ffffff12; cursor: pointer; font-size: 22px;
    }
    .home-header,.home-intro,.actions,.notice { position: relative; z-index: 1; }
    .eyebrow { color: #e8c86d; font-size: 11px; font-weight: 850; letter-spacing: .2em; }
    .home-header {
      display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;
      width: min(1180px,100%); margin: 0 auto 22px; padding-bottom: 15px;
      border-bottom: 1px solid #ffffff1a;
    }
    .brand { display: flex; align-items: center; gap: 11px; color: #fff7db; font-size: 13px; font-weight: 900; letter-spacing: .15em; }
    .brand-mark {
      display: grid; place-items: center; width: 38px; height: 38px;
      border: 1px solid #f2d47a; border-radius: 12px; color: #f5d477;
      background: linear-gradient(145deg,#f5d47722,#f5d47708); font-size: 19px;
    }
    .header-tools { display: flex; align-items: center; gap: 12px; margin-left: auto; }
    .home-meta { color: #a7b3a9; font-size: 11px; font-weight: 750; white-space: nowrap; }
    .version-controls { display: flex; align-items: center; gap: 14px; }
    .version-status { color: #fff; font-size: 12px; font-weight: 500; white-space: nowrap; }
    .logbook-button {
      min-height: 32px; padding: 6px 0; border: 0; color: #fff;
      background: transparent; font-size: 12px; font-weight: 600; cursor: pointer;
    }
    .logbook-panel {
      position: fixed; top: 72px; right: 20px; z-index: 30;
      width: min(360px,calc(100vw - 32px)); max-height: calc(100vh - 96px);
      overflow: auto; padding: 18px; border: 1px solid #f0d47755; border-radius: 16px;
      color: #edf2ff; background: linear-gradient(155deg,#152540f7,#08121ff7);
      box-shadow: 0 20px 70px #000b,0 0 26px #eac45a22;
    }
    .logbook-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .logbook-head h2 { margin: 0; color: #fff; font-size: 16px; font-weight: 600; }
    .logbook-close {
      width: 30px; height: 30px; border: 1px solid #ffffff30; border-radius: 50%;
      color: white; background: #ffffff10; cursor: pointer; font-size: 18px;
    }
    .logbook-summary { margin: 10px 0 14px; color: #ddd; font-size: 12px; }
    .logbook-list { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; }
    .log-entry {
      display: grid; grid-template-columns: 58px minmax(0,1fr); gap: 10px;
      padding: 9px 10px; border: 1px solid #ffffff14; border-radius: 9px; background: #ffffff08;
      font-size: 12px;
    }
    .log-entry strong { color: #fff; font-size: 11px; font-weight: 600; }
    .log-entry span { color: #fff; }
    .creator-panel {
      position: fixed; top: 50%; left: 50%; z-index: 31; display: grid; gap: 14px;
      width: min(420px,calc(100vw - 32px)); max-height: calc(100vh - 40px); overflow: auto;
      padding: 20px; border: 1px solid #f0d47766; border-radius: 16px;
      color: #edf2ff; background: linear-gradient(155deg,#152540f7,#08121ff7);
      box-shadow: 0 20px 70px #000b,0 0 26px #eac45a22; transform: translate(-50%,-50%);
    }
    .creator-panel[hidden] { display: none; }
    .creator-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .creator-head h2 { margin: 0; color: #fff; font-size: 17px; }
    .creator-copy { margin: 0; color: #c5d0e4; font-size: 12px; }
    .creator-form { display: grid; gap: 12px; }
    .creator-field { display: grid; gap: 5px; color: #e5e9f4; font-size: 11px; font-weight: 800; }
    .creator-field input {
      min-height: 40px; width: 100%; padding: 9px 11px; border: 1px solid #ffffff30;
      border-radius: 8px; color: #fff; background: #070f1c; font: inherit;
    }
    .creator-field input:focus-visible { outline: 2px solid #ffe083; outline-offset: 2px; }
    .creator-error { min-height: 18px; margin: 0; color: #ffb1b1; font-size: 12px; }
    .creator-submit { justify-self: start; }
    .home-intro { width: min(1180px,100%); margin: 0 auto 18px; }
    h1 { margin: 8px 0 6px; font-size: clamp(30px,5vw,54px); line-height: 1; letter-spacing: -.045em; }
    .sub { margin: 0; color: #bac7bd; font-size: 14px; }
    .actions { display: flex; flex-wrap: wrap; gap: 10px; margin: 15px 0 0; }
    .primary,.secondary {
      min-height: 42px; border-radius: 10px; padding: 10px 16px; cursor: pointer;
      font-weight: 800;
    }
    .primary {
      border: 0; padding-inline: 21px; color: #172218;
      background: linear-gradient(135deg,#fff1ad,#e5af45);
      box-shadow: 0 5px 22px #e8bd4b35; letter-spacing: .04em;
    }
    .secondary { border: 1px solid #ffffff30; color: #f7f7f2; background: #ffffff12; }
    .actions,.notice { width: min(1180px,100%); margin-left: auto; margin-right: auto; }
    .notice { min-height: 20px; margin-top: 10px; margin-bottom: 10px; color: #e8d79c; font-size: 13px; }
    .pack-area {
      position: relative; display: grid; place-items: center;       width: min(1180px,100%); min-height: clamp(450px,58vh,660px); margin: 0 auto;
      overflow: hidden; isolation: isolate; border: 1px solid #d5bd7135;
      border-radius: 24px;       background:
        radial-gradient(ellipse at 50% 86%,#ffcf6a48,transparent 26%),
        radial-gradient(ellipse at 50% 70%,#1bd5ff35,transparent 42%),
        radial-gradient(ellipse at 50% 5%,#3055ae88,transparent 55%),
        linear-gradient(180deg,#071228 0%,#101e43 53%,#080d1c 100%);
    }
    .pack-area[hidden] { display: none; }
    .pack-area[data-tier="bronze"] {
      --pack-main: #352126; --pack-accent: #f27b65; --pack-line: #ffc097;
      --pack-deep: #291820; --pack-frame: #ffb185; --pack-glow: #f17d5677;
    }
    .pack-area[data-tier="silver"] {
      --pack-main: #242d35; --pack-accent: #dceeff; --pack-line: #a9d8f6;
      --pack-deep: #1c2b3c; --pack-frame: #e7f6ff; --pack-glow: #bce7ff88;
    }
    .pack-area[data-tier="gold"] {
      --pack-main: #302713; --pack-accent: #fff0a0; --pack-line: #f6c94e;
      --pack-deep: #34220d; --pack-frame: #ffe083; --pack-glow: #ffdc6588;
    }
    .pack-area[data-tier="gold-rare"] {
      --pack-main: #152a21; --pack-accent: #55ffa0; --pack-line: #24e887;
      --pack-deep: #09150f; --pack-frame: #85ffb5; --pack-glow: #25f28a99;
    }
    .pack-area[data-tier="galaxy"] {
      --pack-main: #172a63; --pack-accent: #41d7ff; --pack-line: #9c62ff;
      --pack-deep: #090e2b; --pack-frame: #80d5ff; --pack-glow: #5e6dffaa;
    }
    .pack-area[data-tier="rainbow"] {
      --pack-main: #21142c; --pack-accent: #ff609e; --pack-line: #65eaff;
      --pack-deep: #221239; --pack-frame: #fff3ff; --pack-glow: #ff74d9;
    }
    .pack-area[data-tier="rainbow"] .pack-face {
      background: conic-gradient(from 25deg at 50% 50%,#ff4e69,#ff9b43,#fff16a,#58ee90,#51d9ef,#8c73ff,#ee62d0,#ff4e69);
      background-size: 180% 180%;
    }
    .stage-back {
      position: absolute; top: 16px; left: 16px; z-index: 6;
      border: 1px solid #ffffff44; border-radius: 999px; padding: 9px 13px;
      color: #f5f7ff; background: #070d1dcc; cursor: pointer; font-weight: 800;
    }
    .stage-logbook {
      position: absolute; top: 16px; right: 16px; z-index: 6;
      border: 0; padding: 8px 0; color: #fff; background: transparent; cursor: pointer;
      font-size: 12px; font-weight: 500;
    }
    .pack-area::before {
      position: absolute; inset: -20% 5% 10%; z-index: -1; content: "";
      background: conic-gradient(from 180deg at 50% 100%,transparent 0 12deg,#a9ddff20 13deg 14deg,transparent 15deg 27deg,#ffeaa733 28deg 30deg,transparent 31deg 48deg,#fff5c522 49deg 51deg,transparent 52deg 70deg,#fff2b733 71deg 73deg,transparent 74deg 91deg,#fff5c522 92deg 94deg,transparent 95deg);
      filter: blur(7px); opacity: .8;
    }
    .pack-area::after {
      position: absolute; right: 0; bottom: 0; left: 0; height: 23%; z-index: -1;
      content: ""; border-top: 1px solid #e4d28b55;
      background: linear-gradient(180deg,#d2b45a12,transparent),
        repeating-linear-gradient(90deg,transparent 0 8%,#f8eab20c 8.2% 8.4%),
        repeating-linear-gradient(0deg,transparent 0 19%,#f8eab20a 19.2% 19.7%);
      transform: perspective(180px) rotateX(18deg); transform-origin: top;
    }
    .stage-lights {
      position: absolute; inset: 0; z-index: 1; overflow: hidden;
      background:
        conic-gradient(from 166deg at 8% 0%,transparent 0deg,#d8f6ff1b 8deg,transparent 17deg),
        conic-gradient(from 176deg at 28% 0%,transparent 0deg,#fff1bf1b 8deg,transparent 16deg),
        conic-gradient(from 184deg at 72% 0%,transparent 0deg,#fff1bf1b 8deg,transparent 16deg),
        conic-gradient(from 194deg at 92% 0%,transparent 0deg,#d8f6ff1b 8deg,transparent 17deg),
        radial-gradient(ellipse at 50% 68%,#ffe8a329,transparent 43%);
      opacity: .78; transition: opacity .4s, filter .4s;
    }
    .stage-fx {
      position: absolute; inset: 0; z-index: 3; overflow: hidden;
      opacity: 0; pointer-events: none; transition: opacity .3s;
    }
    .stage-fx i {
      position: absolute; top: var(--burst-y); left: var(--burst-x);
      width: 4px; height: 4px; border-radius: 50%; opacity: 0;
      background: #fff7ce; box-shadow: 0 0 8px 3px #ffd879;
    }
    .stage-fx .firework {
      position: absolute; top: var(--firework-y); left: var(--firework-x);
      width: 8px; aspect-ratio: 1; border-radius: 50%; opacity: 0;
      background: radial-gradient(circle,#fff 0 3%,#fff5b9 8%,#ffc75544 30%,transparent 72%);
      filter: drop-shadow(0 0 13px #ffe58a);
    }
    .stage-fx .firework::before {
      position: absolute; inset: -105px; content: "";
      background: repeating-conic-gradient(from 0deg,#ffe8a8 0deg 1deg,transparent 2deg 15deg);
      -webkit-mask: radial-gradient(circle,transparent 0 14%,#000 16% 18%,transparent 20% 100%);
      mask: radial-gradient(circle,transparent 0 14%,#000 16% 18%,transparent 20% 100%);
    }
    .stage-fx .blast {
      position: absolute; top: var(--blast-y,42%); left: var(--blast-x,50%);
      width: 14px; height: 14px; border-radius: 50%; opacity: 0;
      background: radial-gradient(circle,#fff 0 4%,var(--burst-color) 18%,transparent 72%);
      filter: drop-shadow(0 0 18px var(--burst-color));
      transform: translate(-50%,-50%) scale(.05);
    }
    .stage-fx .blast::before {
      position: absolute; inset: -76px; content: "";
      background: repeating-conic-gradient(from 0deg,var(--burst-color) 0deg 1deg,transparent 1.5deg 10deg);
      -webkit-mask: radial-gradient(circle,transparent 0 18%,#000 20% 22%,transparent 24% 100%);
      mask: radial-gradient(circle,transparent 0 18%,#000 20% 22%,transparent 24% 100%);
    }
    .stage-fx .blast-one { --blast-delay: .32s; }
    .stage-fx .blast-two { --blast-delay: .68s; }
    .stage-fx .blast-three { --blast-delay: 1.02s; }
    .stage-fx .cutscene-bars { position: absolute; inset: 0; z-index: 4; visibility: hidden; pointer-events: none; }
    .stage-fx .cutscene-bars::before,.stage-fx .cutscene-bars::after {
      position: absolute; right: 0; left: 0; height: var(--cutscene-height,12%);
      content: ""; background: linear-gradient(180deg,#02040af5,#02040ae8);
      box-shadow: 0 0 24px #000b; transform: scaleY(0);
    }
    .stage-fx .cutscene-bars::before { top: 0; transform-origin: top; }
    .stage-fx .cutscene-bars::after { bottom: 0; transform-origin: bottom; }
    .stage-fx .scene-art {
      position: absolute; inset: 0; z-index: 0; opacity: 0; pointer-events: none;
      --scene-color: #54ffd0; --scene-glow: #1effc4;
    }
    .stage-fx .scene-art::before {
      position: absolute; inset: 0; content: ""; opacity: 0;
      background: radial-gradient(ellipse at 50% 84%,color-mix(in srgb,var(--scene-glow),transparent 30%),transparent 38%);
    }
    .stage-fx .scene-platform {
      position: absolute; bottom: 14%; left: 50%; width: 38%; height: 14px;
      border: 1px solid var(--scene-color); border-radius: 50%;
      background: radial-gradient(ellipse,var(--scene-color),color-mix(in srgb,var(--scene-glow),transparent 62%) 52%,transparent 74%);
      box-shadow: 0 0 24px var(--scene-glow); opacity: 0;
      transform: translateX(-50%) scaleX(.35);
    }
    .stage-fx .scene-jet {
      position: absolute; bottom: 16%; width: 10px; height: 30%;
      border-radius: 50% 50% 0 0;
      background: linear-gradient(0deg,transparent,var(--scene-color) 22%,#fff 48%,var(--scene-color) 60%,transparent);
      box-shadow: 0 0 22px var(--scene-glow); opacity: 0;
      transform: scaleY(.05); transform-origin: bottom;
    }
    .stage-fx .scene-jet-left { left: 14%; }
    .stage-fx .scene-jet-right { right: 14%; }
    .pack-area[data-scene="low"] .scene-art { --scene-color: #5bffd2; --scene-glow: #16ffbf; }
    .pack-area[data-scene="mid"] .scene-art { --scene-color: #ffe59a; --scene-glow: #ffc94f; }
    .pack-area[data-scene="high"] .scene-art { --scene-color: #fff0b0; --scene-glow: #ffba37; }
    .pack-area[data-scene="low"] .scene-jet { width: 8px; height: 27%; }
    .pack-area[data-scene="mid"] .scene-jet { bottom: 13%; width: 16px; height: 40%; }
    .pack-area[data-scene="mid"] .scene-jet-left { left: 25%; }
    .pack-area[data-scene="mid"] .scene-jet-right { right: 25%; }
    .pack-area[data-scene="high"] .scene-jet { bottom: 12%; width: 12px; height: 56%; }
    .pack-area[data-scene="high"] .scene-jet-left { left: 10%; }
    .pack-area[data-scene="high"] .scene-jet-right { right: 10%; }
    .pack-area.is-opening[data-scene] .scene-art,
    .pack-area.is-revealed[data-scene] .scene-art { opacity: 1; }
    .pack-area.is-opening[data-scene="low"] .scene-art::before,
    .pack-area.is-opening[data-scene="mid"] .scene-art::before,
    .pack-area.is-opening[data-scene="high"] .scene-art::before {
      animation: scene-radiance 1.4s ease-out .12s both;
    }
    .pack-area.is-revealed[data-scene] .scene-art::before { opacity: .25; }
    .pack-area.is-opening[data-scene] .scene-platform {
      animation: scene-platform-rise .85s cubic-bezier(.15,.8,.2,1) .38s both;
    }
    .pack-area.is-revealed[data-scene] .scene-platform { opacity: .82; transform: translateX(-50%) scaleX(1); }
    .pack-area.is-opening[data-scene] .scene-jet {
      animation: scene-jet-burst 1.05s ease-out .24s both;
    }
    .pack-area.is-opening .stage-fx,.pack-area.is-revealed .stage-fx { opacity: 1; }
    .pack-area.is-opening .stage-fx i,.pack-area.is-revealed .stage-fx i {
      animation: ember-rise var(--ember-duration) ease-out var(--ember-delay) both;
    }
    .pack-area.is-opening .firework,.pack-area.is-revealed .firework {
      animation: fireworks-burst 1.15s ease-out var(--firework-delay) both;
    }
    .pack-area.is-opening .stage-fx::after {
      position: absolute; inset: 0; content: ""; opacity: 0;
      background: #fff9d8; animation: reveal-flash .75s ease-out 1.35s both;
    }
    .pack-area.is-opening[data-tier="gold"] .stage-fx .blast-one,
    .pack-area.is-opening[data-tier="gold-rare"] .stage-fx .blast-one,
    .pack-area.is-opening[data-tier="galaxy"] .stage-fx .blast-one,
    .pack-area.is-opening[data-tier="rainbow"] .stage-fx .blast-one,
    .pack-area.is-opening[data-tier="gold-rare"] .stage-fx .blast-two,
    .pack-area.is-opening[data-tier="galaxy"] .stage-fx .blast-two,
    .pack-area.is-opening[data-tier="galaxy"] .stage-fx .blast-three,
    .pack-area.is-opening[data-tier="rainbow"] .stage-fx .blast-two,
    .pack-area.is-opening[data-tier="rainbow"] .stage-fx .blast-three {
      animation: blast-bloom 1.05s cubic-bezier(.12,.7,.25,1) var(--blast-delay) both;
    }
    .pack-area.is-opening[data-scene="high"] .stage-fx .cutscene-bars {
      visibility: visible; --cutscene-height: 14%;
    }
    .pack-area.is-opening[data-scene="high"] .stage-fx .cutscene-bars::before,
    .pack-area.is-opening[data-scene="high"] .stage-fx .cutscene-bars::after {
      animation: letterbox-cut 1.8s cubic-bezier(.2,.8,.2,1) .12s both;
    }
    .pack-area.is-opening[data-scene="high"] .stage-fx::after {
      animation-delay: .95s; --flash-opacity: .98;
    }
    .pack-area.is-opening[data-scene="mid"] { animation: stage-impact .52s ease-out .9s both; }
    .pack-area.is-opening[data-scene="high"] { animation: stage-impact-strong .72s ease-out .88s both; }
    .tunnel {
      position: absolute; inset: 0; z-index: 5; overflow: hidden; visibility: hidden;
      opacity: 0; pointer-events: none; perspective: 700px;
      background: radial-gradient(ellipse at center,#101a35 0,#050812 48%,#010205 100%);
      transition: opacity .25s, visibility .25s;
    }
    .pack-area.is-tunneling .tunnel { visibility: visible; opacity: 1; }
    .pack-area.is-tunneling .stage-fx,.pack-area.is-tunneling .stage-lights,
    .pack-area.is-tunneling .side-card { opacity: 0; transition: opacity .5s; }
    .pack-area.is-tunneling .pack.opening {
      animation: pack-enter-tunnel 1.15s cubic-bezier(.45,0,.8,.25) both;
    }
    .tunnel-rings { position: absolute; inset: 0; transform-style: preserve-3d; }
    .tunnel-ring {
      position: absolute; top: 50%; left: 50%; width: var(--ring-width);
      height: var(--ring-height); border: 2px solid var(--tunnel-color,#85dfff);
      border-radius: 50%; box-shadow: 0 0 18px var(--tunnel-glow,#527cff),inset 0 0 18px var(--tunnel-glow,#527cff);
      opacity: 0; transform: translate(-50%,-50%) scale(.04);
    }
    .tunnel-rays {
      position: absolute; inset: -60%; opacity: 0;
      background: repeating-conic-gradient(from 0deg at 50% 50%,transparent 0deg 7deg,var(--tunnel-ray,#9bcfff22) 8deg 9deg,transparent 10deg 18deg);
      transform: scale(.2);
    }
    .pack-area.is-tunneling .tunnel-rays { animation: tunnel-rays-zoom 2.5s ease-in both; }
    .pack-area.is-tunneling .tunnel-ring { animation: tunnel-ring-rush 1.6s cubic-bezier(.12,.72,.24,1) var(--ring-delay) both; }
    .tunnel::after {
      position: absolute; inset: 0; content: ""; opacity: 0;
      background: radial-gradient(ellipse at center,#fff 0,#d6f4ff 8%,#8bcaff99 26%,transparent 68%);
    }
    .pack-area.is-tunneling .tunnel::after { animation: tunnel-exit-flash .7s ease-out 2.15s both; }
    .pack-area[data-scene="low"] { --tunnel-color:#65ffe0; --tunnel-glow:#18e9bd; --tunnel-ray:#7dffe022; }
    .pack-area[data-scene="mid"] { --tunnel-color:#ffe7a0; --tunnel-glow:#ffc84c; --tunnel-ray:#ffe59a22; }
    .pack-area[data-scene="high"] { --tunnel-color:#b9a2ff; --tunnel-glow:#774cff; --tunnel-ray:#d6b7ff33; }
    @keyframes tunnel-ring-rush {
      0% { opacity: 0; transform: translate(-50%,-50%) scale(.04); }
      12% { opacity: .9; }
      100% { opacity: 0; transform: translate(-50%,-50%) scale(5.2); }
    }
    @keyframes tunnel-rays-zoom {
      0% { opacity: 0; transform: scale(.15) rotate(0); }
      18% { opacity: .75; }
      100% { opacity: 0; transform: scale(1.7) rotate(18deg); }
    }
    @keyframes tunnel-exit-flash {
      0%,35% { opacity: 0; }
      55% { opacity: .95; }
      100% { opacity: 0; }
    }
    @keyframes pack-enter-tunnel {
      0% { opacity: 1; transform: scale(1); filter: brightness(1); }
      28% { opacity: 1; transform: scale(.82); }
      100% { opacity: 0; transform: scale(.025); filter: brightness(4); }
    }
    @keyframes ember-rise {
      0% { opacity: 0; transform: translate3d(0,35px,0) scale(.3); }
      15% { opacity: 1; }
      100% { opacity: 0; transform: translate3d(var(--ember-drift),-240px,0) scale(0); }
    }
    @keyframes fireworks-burst {
      0% { opacity: 0; transform: scale(.05); }
      18% { opacity: 1; }
      100% { opacity: 0; transform: scale(var(--firework-end-scale,1.7)); }
    }
    @keyframes blast-bloom {
      0% { opacity: 0; transform: translate(-50%,-50%) scale(.05); }
      14% { opacity: 1; }
      100% { opacity: 0; transform: translate(-50%,-50%) scale(var(--blast-scale,3.2)); }
    }
    @keyframes letterbox-cut {
      0%,100% { transform: scaleY(0); }
      16%,78% { transform: scaleY(1); }
    }
    @keyframes scene-radiance {
      0% { opacity: 0; transform: scale(.7); }
      30% { opacity: .9; }
      100% { opacity: 0; transform: scale(1.15); }
    }
    @keyframes scene-platform-rise {
      0% { opacity: 0; transform: translateX(-50%) scaleX(.25); }
      55% { opacity: 1; transform: translateX(-50%) scaleX(1.08); }
      100% { opacity: .82; transform: translateX(-50%) scaleX(1); }
    }
    @keyframes scene-jet-burst {
      0% { opacity: 0; transform: scaleY(.05); }
      18% { opacity: 1; transform: scaleY(1.08); }
      62% { opacity: .95; transform: scaleY(.78); }
      100% { opacity: 0; transform: scaleY(0); }
    }
    @keyframes stage-impact {
      0%,100% { transform: translateX(0); }
      18%,58% { transform: translateX(-8px); }
      38%,78% { transform: translateX(8px); }
    }
    @keyframes stage-impact-strong {
      0%,100% { transform: translateX(0); }
      16%,56% { transform: translateX(-13px); }
      36%,76% { transform: translateX(13px); }
    }
    @keyframes reveal-flash {
      0%,58% { opacity: 0; }
      68% { opacity: var(--flash-opacity,.92); }
      100% { opacity: 0; }
    }
    .pack-area[data-tier="bronze"] .stage-fx { --burst-color: #ffb185; }
    .pack-area[data-tier="silver"] .stage-fx { --burst-color: #c5eeff; }
    .pack-area[data-tier="gold"] .stage-fx { --burst-color: #ffe083; }
    .pack-area[data-tier="gold-rare"] .stage-fx { --burst-color: #55ffa0; }
    .pack-area[data-tier="galaxy"] .stage-fx { --burst-color: #80a9ff; }
    .pack-area[data-tier="rainbow"] .stage-fx { --burst-color: #ff9ee8; }
    .pack-area[data-tier="bronze"] .stage-fx { --firework-end-scale: .9; --flash-opacity: .35; }
    .pack-area[data-tier="silver"] .stage-fx { --firework-end-scale: 1.15; --flash-opacity: .5; }
    .pack-area[data-tier="gold"] .stage-fx { --firework-end-scale: 1.4; --blast-scale: 2.6; --flash-opacity: .65; }
    .pack-area[data-tier="gold-rare"] .stage-fx { --firework-end-scale: 1.7; --blast-scale: 3.4; --flash-opacity: .78; }
    .pack-area[data-tier="galaxy"] .stage-fx { --firework-end-scale: 2; --blast-scale: 4; --flash-opacity: .9; }
    .pack-area[data-tier="rainbow"] .stage-fx { --firework-end-scale: 2.4; --blast-scale: 5; --flash-opacity: 1; }
    .pack-area[data-tier="bronze"] .stage-fx i:nth-of-type(n+7),
    .pack-area[data-tier="bronze"] .stage-fx .firework-two,
    .pack-area[data-tier="bronze"] .stage-fx .firework-three { display: none; }
    .pack-area[data-tier="silver"] .stage-fx i:nth-of-type(n+12),
    .pack-area[data-tier="silver"] .stage-fx .firework-three { display: none; }
    .pack-area[data-tier="gold"] .stage-fx i:nth-of-type(n+16) { display: none; }
    .pack-area[data-scene="low"] .stage-fx i:nth-of-type(n+7),
    .pack-area[data-scene="low"] .stage-fx .firework-two,
    .pack-area[data-scene="low"] .stage-fx .firework-three,
    .pack-area[data-scene="low"] .stage-fx .blast { display: none; }
    .pack-area[data-tier] .stage-fx i { background: var(--burst-color,#fff7ce); box-shadow: 0 0 8px 3px var(--burst-color,#ffd879); }
    .pack-area[data-tier] .stage-fx .firework { filter: drop-shadow(0 0 13px var(--burst-color,#ffe58a)); }
    .pack-area[data-tier] .stage-fx .firework::before { background: repeating-conic-gradient(from 0deg,var(--burst-color,#ffe8a8) 0deg 1deg,transparent 2deg 15deg); }
    .stage-fx .blast-one { --blast-x: 24%; --blast-y: 45%; }
    .stage-fx .blast-two { --blast-x: 76%; --blast-y: 39%; }
    .stage-fx .blast-three { --blast-x: 50%; --blast-y: 24%; }
    .side-card[data-tier="bronze"] { --side-color: #ffb185; --side-deep: #291820; --side-glow: #f17d5677; }
    .side-card[data-tier="silver"] { --side-color: #e7f6ff; --side-deep: #1c2b3c; --side-glow: #bce7ff99; }
    .side-card[data-tier="gold"] { --side-color: #ffe083; --side-deep: #34220d; --side-glow: #ffdc6588; }
    .side-card[data-tier="gold-rare"] { --side-color: #85ffb5; --side-deep: #09150f; --side-glow: #25f28a99; }
    .side-card[data-tier="galaxy"] { --side-color: #80d5ff; --side-deep: #090e2b; --side-glow: #5e6dffaa; }
    .side-card[data-tier="rainbow"] { --side-color: #ff9ee8; --side-deep: #221239; --side-glow: #ff74d9; }
    .side-card[data-tier] {
      border-color: color-mix(in srgb,var(--side-color),transparent 25%);
      background: linear-gradient(145deg,var(--side-color),var(--side-deep) 46%,#101222);
      box-shadow: 0 0 28px var(--side-glow);
    }
    .stage-fx .firework-one { --firework-x: 16%; --firework-y: 26%; --firework-delay: .08s; }
    .stage-fx .firework-two { --firework-x: 82%; --firework-y: 22%; --firework-delay: .36s; }
    .stage-fx .firework-three { --firework-x: 50%; --firework-y: 10%; --firework-delay: .68s; }
    .pack-area.is-opening .stage-lights { animation: stadium-flash .75s ease-in-out 2; }
    .pack-area.is-revealed .stage-lights { animation: stadium-glow 2.5s ease-in-out infinite alternate; }
    @keyframes stadium-glow {
      from { filter: brightness(1); }
      to { filter: brightness(1.65); }
    }
    .side-card {
      position: absolute; top: 50%; z-index: 2; display: flex; flex-direction: column;
      justify-content: space-between; align-items: flex-start;
      width: clamp(82px,12vw,150px); height: clamp(130px,21vw,230px); padding: 14px;
      border: 2px solid #f5dc9a99; border-radius: 8px;
      background: linear-gradient(145deg,#fff4c4,#9a7939 42%,#18213b 75%,#101222);
      box-shadow: 0 0 28px #ffda7a40; opacity: .92; color: #fff;
      cursor: pointer; font: inherit; text-align: left;
      transform: translateY(-50%) perspective(500px) rotateY(18deg);
      transition: transform .25s, box-shadow .25s;
    }
    .side-card[hidden] { display: none; }
    .side-card:hover { transform: translateY(-50%) perspective(500px) rotateY(18deg) scale(1.04); }
    .side-card:focus-visible { outline: 3px solid #fff; outline-offset: 3px; }
    .side-card.is-opened { border-radius: 8px; }
    .side-card.is-sealed { border-radius: 16px 16px 24px 24px; }
    .side-card::before {
      position: absolute; inset: 9px; z-index: 0; content: ""; border: 1px solid #fff9;
      background:
        radial-gradient(ellipse at 50% 38%,#fff8,transparent 42%),
        linear-gradient(145deg,transparent 38%,#fff8 39%,transparent 42%);
    }
    .side-card.is-sealed::before { border-radius: 9px 9px 16px 16px; }
    .side-card.is-sealed::after {
      position: absolute; top: 47%; right: -14%; left: -14%; z-index: 0; height: 10px;
      content: ""; background: linear-gradient(90deg,transparent,var(--side-color),transparent);
      box-shadow: 0 0 14px var(--side-glow); opacity: .75; transform: rotate(-24deg);
    }
    .side-card > span,.side-card > strong { position: relative; z-index: 1; }
    .side-rating { color: var(--side-color,#fff); font-size: clamp(24px,3vw,38px); font-weight: 1000; line-height: 1; text-shadow: 0 2px 8px #000b; }
    .side-subject { display: -webkit-box; overflow: hidden; color: #fff; font-size: 11px; font-weight: 950; line-height: 1.15; overflow-wrap: anywhere; text-overflow: ellipsis; text-transform: uppercase; -webkit-box-orient: vertical; -webkit-line-clamp: 3; }
    .side-tier { color: var(--side-color,#fff); font-size: 8px; font-weight: 950; letter-spacing: .1em; }
    .side-state,.side-pack-mark,.side-pack-hint { color: var(--side-color,#fff); font-size: 7px; font-weight: 950; letter-spacing: .12em; }
    .side-pack-mark { letter-spacing: .2em; }
    .side-pack-title { align-self: center; color: #fff; font-size: clamp(13px,1.8vw,20px); font-weight: 1000; line-height: 1.05; text-align: center; text-shadow: 0 2px 8px #000b; }
    .side-pack-subject { color: #fff; font-size: 9px; font-weight: 900; line-height: 1.15; overflow-wrap: anywhere; text-align: center; text-transform: uppercase; }
    .side-left { left: 9%; }
    .side-right { right: 9%; transform: translateY(-50%) perspective(500px) rotateY(-18deg); }
    .side-right:hover { transform: translateY(-50%) perspective(500px) rotateY(-18deg) scale(1.04); }
    .pack {
      position: relative; z-index: 2; display: grid; place-items: center;
      width: 218px; height: 316px; border: 0; padding: 0; color: #fff3bd;
      background: transparent; cursor: pointer; perspective: 900px;
      filter: drop-shadow(0 18px 35px #000b); transition: transform .35s;
    }
    .pack:hover { transform: translateY(-7px) scale(1.025); }
    .pack-face {
      position: absolute; inset: 0; display: grid; align-content: center;
      justify-items: center; gap: 8px; overflow: hidden; border-radius: 18px 18px 26px 26px;
      border: 2px solid #a6f8ff;       background:
        linear-gradient(156deg,transparent 36%,var(--pack-accent,#f7259d) 37% 44%,transparent 45%),
        linear-gradient(166deg,transparent 49%,var(--pack-line,#24e9ff) 50% 53%,transparent 54%),
        radial-gradient(ellipse at 50% 15%,var(--pack-main,#20334f),var(--pack-deep,#090d1d) 72%);
      border-color: var(--pack-frame,#a6f8ff);
      box-shadow: inset 0 0 0 6px var(--pack-deep,#090d1d),inset 0 0 35px var(--pack-glow,#43eaff55);
      transition: transform .6s, filter .5s;
    }
    .pack-face::before {
      position: absolute; inset: 12px; content: ""; border-radius: 12px 12px 20px 20px;
      border: 1px solid color-mix(in srgb,var(--pack-frame,#a6f8ff),transparent 12%);
      background: repeating-linear-gradient(135deg,transparent 0 16px,color-mix(in srgb,var(--pack-frame,#a6f8ff),transparent 84%) 17px 18px);
    }
    .pack-mark,.pack-title,.pack-hint { position: relative; z-index: 1; color: #effcff; text-shadow: 0 2px 8px #000; }
    .pack-mark { font-size: 12px; font-weight: 900; letter-spacing: .28em; }
    .pack-title { max-width: 100%; font-size: clamp(20px,3vw,28px); font-weight: 1000; letter-spacing: .04em; line-height: 1.05; overflow-wrap: anywhere; text-align: center; }
    .pack-hint { font-size: 10px; font-weight: 900; letter-spacing: .18em; }
    .pack.opening { animation: pack-shake .7s ease-in-out 2; }
    .pack.opening .pack-face { animation: pack-flash 1.8s ease-in-out forwards; }
    .pack-area.is-opening[data-scene="high"] .pack.opening { animation: pack-legendary 2s cubic-bezier(.2,.72,.24,1) both; }
    .pack-area.is-opening[data-scene="high"] .pack.opening .pack-face { animation: pack-face-legendary 1.9s ease-in-out both; }
    .pack-area.is-opening .stage-lights { opacity: 1; filter: brightness(2.6); }
    .pack-area.is-revealed .pack { opacity: 0; transform: scale(.65) translateY(55px); pointer-events: none; }
    @keyframes stadium-flash {
      0%,100% { opacity: .35; filter: brightness(1); }
      50% { opacity: 1; filter: brightness(2.8); }
    }
    @keyframes pack-shake {
      0%,100% { transform: translateX(0) scale(1); }
      20% { transform: translateX(-9px) rotate(-3deg) scale(1.04); }
      40% { transform: translateX(9px) rotate(3deg) scale(1.08); }
      60% { transform: translateX(-6px) rotate(-2deg); }
      80% { transform: translateX(6px) rotate(2deg) scale(1.05); }
    }
    @keyframes pack-flash {
      0%,45% { filter: brightness(1); }
      60% { filter: brightness(1.3); transform: scale(1.05); }
      78% { filter: brightness(3.5); transform: scale(1.18); }
      100% { filter: brightness(.1); transform: scale(.68) rotateY(90deg); }
    }
    @keyframes pack-legendary {
      0%,12% { opacity: 1; transform: translateY(0) rotateY(0) scale(1); }
      30% { transform: translateY(-16px) rotateY(-24deg) rotateZ(-4deg) scale(1.08); }
      52% { transform: translateY(-10px) rotateY(170deg) rotateZ(3deg) scale(1.12); }
      72% { transform: translateY(-18px) rotateY(360deg) scale(1.24); }
      100% { opacity: 0; transform: translateY(12px) rotateY(720deg) scale(.2); }
    }
    @keyframes pack-face-legendary {
      0%,48% { filter: brightness(1); }
      67% { filter: brightness(4); transform: scale(1.12); }
      100% { filter: brightness(.08); transform: scale(.24) rotateY(90deg); }
    }
    .result-area {
      position: absolute; inset: 0; z-index: 6; display: grid; place-items: center;
      overflow: hidden; padding: 28px 16px 16px;
      pointer-events: none;
    }
    .result-area:empty { display: none; }
    .result {
      --card-accent: #d98b59;
      --card-deep: #062b32;
      --card-ink: #fff7df;
      --card-glow: #36e0c599;
      position: relative; display: grid; grid-template-columns: minmax(0,1fr);
      grid-template-rows: auto minmax(130px,1fr) auto auto auto; gap: 5px;
      width: min(260px,100%); height: min(410px,100%); min-width: 0; min-height: 0; max-height: 100%;
      padding: 16px 16px 30px; overflow: hidden;
      clip-path: polygon(0 8%,12% 7%,20% 4%,39% 4%,50% 0,61% 4%,80% 4%,88% 7%,100% 8%,100% 88%,95% 94%,50% 100%,5% 94%,0 88%);
      border: 0; color: var(--card-ink); text-align: center;
      background:
        linear-gradient(120deg,transparent 20%,#ffffff00 34%,#ffffff88 46%,#ffffff00 56%,transparent 70%),
        radial-gradient(ellipse at 50% 38%,#176e68,#0c4e4b 42%,var(--card-deep) 100%),
        repeating-linear-gradient(135deg,transparent 0 19px,#ffffff0c 20px 21px);
      background-size: 250% 100%,100% 100%,100% 100%;
      box-shadow: 0 0 25px var(--card-glow),0 0 90px var(--card-glow),0 28px 70px #000b,inset 0 0 0 6px var(--card-deep),inset 0 0 30px #fff9;
      transform-style: preserve-3d;
      animation: card-rise 1.25s cubic-bezier(.16,.85,.25,1.25) both, card-foil 4s ease-in-out 1.8s infinite;
    }
    .result[data-tier="bronze"] {
      --card-accent: #e89a6b; --card-glow: #ed825688;
    }
    .result[data-tier="silver"] {
      --card-accent: #d8edf8; --card-glow: #bce7ff99;
    }
    .result[data-tier="gold"] {
      --card-accent: #ffe083; --card-glow: #ffdc6588;
    }
    .result[data-tier="gold-rare"] {
      --card-accent: #69f0ae; --card-glow: #39ff9799;
      animation: card-rise 1.25s cubic-bezier(.16,.85,.25,1.25) both, card-foil 3.6s ease-in-out 1.8s infinite, card-aura 1.6s ease-in-out 1.8s infinite alternate;
    }
    .result[data-tier="galaxy"] {
      --card-accent: #aab8ff; --card-glow: #6991ff;
      animation: card-rise 1.25s cubic-bezier(.16,.85,.25,1.25) both, galaxy-glow 1.3s ease-in-out 1.8s infinite alternate, card-foil 4s ease-in-out 1.8s infinite, card-aura 1.3s ease-in-out 1.8s infinite alternate;
    }
    .result[data-tier="rainbow"] {
      --card-accent: #ffb1e9; --card-glow: #ff74d9;
      animation: card-rise 1.45s cubic-bezier(.16,.85,.25,1.25) both, card-foil 2.8s ease-in-out 1.8s infinite, card-aura 1s ease-in-out 1.8s infinite alternate;
      background:
        linear-gradient(120deg,transparent 20%,#ffffff00 34%,#ffffffaa 46%,#ffffff00 56%,transparent 70%),
        radial-gradient(ellipse at 50% 0%,#fff9,transparent 45%),
        conic-gradient(from 25deg at 50% 50%,#ff4e69,#ff9b43,#fff16a,#58ee90,#51d9ef,#8c73ff,#ee62d0,#ff4e69);
      background-size: 250% 100%,100% 100%,100% 100%;
    }
    @keyframes card-foil {
      0%,100% { background-position: -180% center,center,center; }
      55% { background-position: 180% center,center,center; }
    }
    @keyframes galaxy-glow {
      from { filter: drop-shadow(0 0 0 var(--card-glow)); }
      to { filter: drop-shadow(0 0 20px var(--card-glow)); }
    }
    @keyframes card-aura {
      from { box-shadow: 0 0 25px var(--card-glow),0 0 90px var(--card-glow),0 28px 70px #000b,inset 0 0 0 6px var(--card-deep),inset 0 0 30px #fff9; }
      to { box-shadow: 0 0 42px var(--card-glow),0 0 120px var(--card-glow),0 28px 70px #000b,inset 0 0 0 6px var(--card-deep),inset 0 0 30px #fff9; }
    }
    .result::before {
      position: absolute; inset: 10px; content: "";
      clip-path: polygon(0 8%,12% 7%,20% 4%,39% 4%,50% 0,61% 4%,80% 4%,88% 7%,100% 8%,100% 88%,95% 94%,50% 100%,5% 94%,0 88%);
      background: repeating-linear-gradient(135deg,transparent 0 17px,#ffffff14 18px 19px);
      pointer-events: none;
    }
    .card-outline {
      position: absolute; inset: 0; z-index: 0; width: 100%; height: 100%;
      color: var(--card-accent); filter: drop-shadow(0 0 2px var(--card-glow));
      pointer-events: none;
    }
    .result::after {
      position: absolute; inset: 0; content: ""; pointer-events: none;
      background: linear-gradient(115deg,transparent 30%,#fff5 48%,transparent 55%);
      transform: translateX(-130%); animation: card-sheen 1.2s ease-out .55s both;
    }
    @keyframes card-sheen {
      to { transform: translateX(130%); }
    }
    .sparkles { position: absolute; inset: 0; z-index: 3; overflow: hidden; pointer-events: none; }
    .sparkles i {
      position: absolute; top: var(--spark-y); left: var(--spark-x); width: var(--spark-size);
      height: var(--spark-size); border-radius: 50%; opacity: 0;
      background: #fffce7; box-shadow: 0 0 9px 3px var(--card-accent);
      animation: sparkle-pop 1.5s ease-out var(--spark-delay) both;
    }
    @keyframes sparkle-pop {
      0% { opacity: 0; transform: translateY(15px) scale(.1); }
      20% { opacity: 1; }
      75% { opacity: .9; }
      100% { opacity: 0; transform: translateY(-42px) scale(.3); }
    }
    .card-rating { position: relative; z-index: 1; grid-column: 1 / -1; grid-row: 1; display: grid; justify-items: center; align-content: center; color: var(--card-accent); text-shadow: 0 2px 8px #0008; }
    .card-rating-label { font-size: 8px; font-weight: 950; letter-spacing: .16em; }
    .card-rating strong { font-size: 36px; font-weight: 1000; line-height: 1; }
    .card-art {
      position: relative; z-index: 1; grid-column: 1 / -1; display: grid;
      place-items: center; min-width: 0; min-height: 0; overflow: hidden;
      background:
        radial-gradient(ellipse at 50% 45%,color-mix(in srgb,var(--card-accent),transparent 78%),transparent 65%),
        conic-gradient(from 25deg at 50% 50%,transparent 0 7deg,color-mix(in srgb,var(--card-accent),transparent 72%) 8deg 9deg,transparent 10deg 24deg);
    }
    .card-art::before {
      position: absolute; inset: 8px 24px; content: "";
      clip-path: polygon(50% 0,95% 24%,95% 72%,50% 100%,5% 72%,5% 24%);
      border: 1px solid color-mix(in srgb,var(--card-accent),transparent 38%);
      background: linear-gradient(145deg,#ffffff0c,transparent 58%,#ffffff08);
    }
    .card-art::after {
      position: absolute; top: 50%; left: 50%; width: 78px; height: 78px; content: "";
      border: 1px solid color-mix(in srgb,var(--card-accent),transparent 48%);
      background: radial-gradient(circle,color-mix(in srgb,var(--card-accent),transparent 88%),transparent 70%);
      box-shadow: 0 0 28px color-mix(in srgb,var(--card-accent),transparent 80%);
      transform: translate(-50%,-50%) rotate(45deg);
    }
    .card-crest {
      position: relative; z-index: 1; display: grid; place-items: center;
      width: 60px; height: 60px; color: var(--card-accent); font-size: 42px;
      line-height: 1; text-shadow: 0 0 18px var(--card-glow);
    }
    .card-meme {
      position: relative; z-index: 1; display: block; width: auto; height: auto;
      max-width: min(132px,100%); max-height: min(158px,100%);
      border: 0; border-radius: 0; object-fit: contain;
    }
    .card-info { position: relative; z-index: 1; grid-column: 1 / -1; min-width: 0; }
    .card-info h2 { margin: 0 0 4px; color: var(--card-accent); font-size: 20px; line-height: 1.1; overflow-wrap: anywhere; text-transform: uppercase; text-shadow: 0 2px 8px #0008; }
    .card-info p { margin: 3px 0 0; color: var(--card-ink); font-size: 11px; font-weight: 750; overflow-wrap: anywhere; }
    .card-details {
      position: relative; z-index: 1; grid-column: 1 / -1; display: grid;
      grid-template-columns: minmax(0,1fr) minmax(0,1fr); gap: 7px 14px; min-width: 0; margin-top: 4px;
      padding: 8px 0 32px; border-top: 1px solid color-mix(in srgb,var(--card-accent),transparent 35%); text-align: left;
    }
    .card-details .card-stat:last-child:nth-child(odd) {
      grid-column: 1 / -1; justify-self: center; width: min(70%,170px); text-align: center;
    }
    .card-stat { display: grid; gap: 2px; min-width: 0; }
    .card-stat b { overflow: hidden; color: color-mix(in srgb,var(--card-accent),transparent 22%); font-size: 8px; font-weight: 1000; letter-spacing: .11em; text-overflow: ellipsis; white-space: nowrap; }
    .card-stat strong { overflow: hidden; color: var(--card-ink); font-size: 12px; font-weight: 950; text-overflow: ellipsis; white-space: nowrap; }
    .card-tier {
      position: relative; z-index: 1; grid-column: 1 / -1; color: var(--card-accent);
      font-size: 10px; font-weight: 1000; letter-spacing: .16em;
    }
    @keyframes card-rise {
      0% { opacity: 0; transform: translateY(200px) scale(.3) rotateY(70deg); filter: brightness(3); }
      58% { opacity: 1; transform: translateY(-17px) scale(1.08) rotateY(-9deg); filter: brightness(1.5); }
      78% { transform: translateY(4px) scale(.99) rotateY(3deg); }
      100% { opacity: 1; transform: translateY(0) scale(1) rotateY(0); filter: brightness(1); }
    }
    .section-title {
      display: flex; justify-content: space-between; align-items: baseline;
      width: min(1180px,100%); margin: 28px auto 12px; padding-bottom: 10px;
      border-bottom: 1px solid #ffffff24; font-size: 18px; letter-spacing: .04em;
    }
    .section-title small { color: #b8cce8; font-size: 12px; font-weight: 650; }
    .squad-section { width: min(1120px,100%); margin: 30px auto 0; }
    .squad-pitch {
      position: relative; display: grid; grid-template-rows: repeat(4,minmax(0,1fr));
      gap: 7px; min-height: 490px; overflow: hidden; padding: 22px 16px;
      border: 1px solid #a2f6d855; border-radius: 16px;
      background:
        repeating-linear-gradient(90deg,#ffffff06 0 12.5%,transparent 12.5% 25%),
        radial-gradient(ellipse at 50% 50%,#1f6846,#105134 70%,#0b3d2c);
      box-shadow: inset 0 0 45px #061c19aa,0 16px 38px #0005;
    }
    .squad-pitch[hidden] { display: none; }
    .pitch-markings {
      position: absolute; inset: 16px; z-index: 0; border: 1px solid #effff044;
      border-radius: 10px; pointer-events: none;
    }
    .pitch-markings::before {
      position: absolute; top: 50%; right: 0; left: 0; content: "";
      border-top: 1px solid #effff044;
    }
    .pitch-markings::after {
      position: absolute; top: 50%; left: 50%; width: 90px; aspect-ratio: 1;
      border: 1px solid #effff044; border-radius: 50%; content: "";
      transform: translate(-50%,-50%);
    }
    .pitch-box {
      position: absolute; left: 50%; width: 34%; height: 11%;
      border: 1px solid #effff044; transform: translateX(-50%);
    }
    .pitch-box-top { top: 0; border-top: 0; }
    .pitch-box-bottom { bottom: 0; border-bottom: 0; }
    .squad-links { position: absolute; inset: 0; z-index: 0; width: 100%; height: 100%; pointer-events: none; }
    .squad-links path {
      fill: none; stroke: #43ffb7; stroke-width: 2; stroke-dasharray: 7 6;
      opacity: .72; filter: drop-shadow(0 0 4px #29f3a5);
    }
    .squad-links path:nth-child(even) { stroke: #ffc95e; filter: drop-shadow(0 0 4px #ffc95e); }
    .squad-row {
      position: relative; z-index: 1; display: grid; align-items: center;
      justify-items: center; justify-self: center; width: 100%;
    }
    .squad-row[data-line="attack"],.squad-row[data-line="midfield"] {
      width: 78%; grid-template-columns: repeat(3,minmax(0,1fr));
    }
    .squad-row[data-line="defence"] { grid-template-columns: repeat(4,minmax(0,1fr)); }
    .squad-row[data-line="goalkeeper"] { width: 25%; grid-template-columns: minmax(0,1fr); }
    .lineup-player {
      display: grid; justify-items: center; gap: 3px; width: clamp(62px,8vw,94px);
      border: 0; padding: 2px; color: #f7fbff; background: transparent;
      cursor: pointer; font: inherit; text-align: center;
    }
    .lineup-player:hover,.lineup-player:focus-visible { transform: translateY(-3px); outline: none; }
    .lineup-player:focus-visible .lineup-card { outline: 2px solid #fff; outline-offset: 3px; }
    .lineup-card {
      position: relative; display: grid; grid-template-rows: auto minmax(0,1fr) auto;
      justify-items: center; align-items: center; gap: 3px; width: 100%; aspect-ratio: .7;
      overflow: hidden; padding: 6px 4px; border: 1px solid var(--pack-light,#f8d878);
      border-radius: 7px; color: #fff; background:
        linear-gradient(140deg,#ffffff1c,transparent 38%),
        radial-gradient(ellipse at 50% 40%,color-mix(in srgb,var(--pack-light),transparent 82%),transparent 65%),
        linear-gradient(145deg,var(--pack-main,#253c53),var(--pack-deep,#0a1422));
      box-shadow: 0 0 0 1px var(--pack-glow,#ffffff33),0 5px 12px #0009;
    }
    .lineup-card[data-tier="bronze"] { --pack-main:#352126; --pack-light:#ffc097; --pack-deep:#100d13; --pack-glow:#f17d5677; }
    .lineup-card[data-tier="silver"] { --pack-main:#242d35; --pack-light:#e7f6ff; --pack-deep:#10151b; --pack-glow:#bce7ff99; }
    .lineup-card[data-tier="gold"] { --pack-main:#302713; --pack-light:#ffe083; --pack-deep:#13100b; --pack-glow:#ffdc6588; }
    .lineup-card[data-tier="gold-rare"] { --pack-main:#152a21; --pack-light:#55ffa0; --pack-deep:#09150f; --pack-glow:#25f28a99; }
    .lineup-card[data-tier="galaxy"] { --pack-main:#172a63; --pack-light:#80d5ff; --pack-deep:#090e2b; --pack-glow:#5e6dffaa; }
    .lineup-card[data-tier="rainbow"] { --pack-main:#21142c; --pack-light:#fff3ff; --pack-deep:#0d0a15; --pack-glow:#ff74d9; }
    .lineup-card::after {
      position: absolute; inset: 4px; border: 1px solid color-mix(in srgb,var(--pack-light,#fff),transparent 55%);
      border-radius: 4px; content: ""; pointer-events: none;
    }
    .lineup-rating { position: relative; z-index: 1; color: var(--pack-light,#ffe083); font-size: clamp(14px,2vw,20px); font-weight: 1000; line-height: 1; }
    .lineup-meme { position: relative; z-index: 1; display: block; width: 80%; max-height: 45px; object-fit: contain; }
    .lineup-emblem { position: relative; z-index: 1; color: var(--pack-light,#ffe083); font-size: 25px; }
    .lineup-subject { position: relative; z-index: 1; display: -webkit-box; max-width: 100%; overflow: hidden; font-size: 7px; font-weight: 950; line-height: 1.05; text-overflow: ellipsis; text-transform: uppercase; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    .lineup-position { color: #e8ffe9; font-size: 8px; font-weight: 850; text-shadow: 0 1px 5px #000; }
    .lineup-empty {
      display: grid; place-content: center; justify-items: center; gap: 3px;
      width: clamp(62px,8vw,94px); aspect-ratio: .7; border: 1px dashed #dfffe566;
      border-radius: 7px; color: #dfffe5aa; background: #041d1855;
      font-size: 8px; font-weight: 850; text-align: center;
    }
    .lineup-empty strong { font-size: 19px; font-weight: 400; }
    .squad-bench { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin: 12px auto 0; }
    .squad-bench:empty { display: none; }
    .squad-bench .lineup-player { width: 72px; }
    .squad-bench .lineup-card { padding: 5px 3px; }
    .grades {
      display: grid; grid-template-columns: repeat(4,minmax(0,1fr));
      gap: clamp(10px,1.6vw,20px); width: min(940px,100%); margin: 0 auto;
    }
    .grade-pack {
      --pack-main: #352126; --pack-light: #ffc097; --pack-deep: #100d13;
      --pack-glow: #f17d5677;
      display: grid; justify-items: center; align-content: start; gap: 5px; min-width: 0;
      padding: 6px 3px; border: 1px solid transparent; border-radius: 10px;
      color: #f4f6ff; background: transparent;
      text-align: center; cursor: pointer;
      transition: transform .25s, background .25s, border-color .25s;
    }
    .grade-pack[data-tier="bronze"] { --pack-main:#352126; --pack-light:#ffc097; --pack-deep:#100d13; --pack-glow:#f17d5677; }
    .grade-pack[data-tier="silver"] { --pack-main:#242d35; --pack-light:#e7f6ff; --pack-deep:#10151b; --pack-glow:#bce7ff99; }
    .grade-pack[data-tier="gold"] { --pack-main:#302713; --pack-light:#ffe083; --pack-deep:#13100b; --pack-glow:#ffdc6588; }
    .grade-pack[data-tier="gold-rare"] { --pack-main:#152a21; --pack-light:#55ffa0; --pack-deep:#09150f; --pack-glow:#25f28a99; }
    .grade-pack[data-tier="galaxy"] { --pack-main:#172a63; --pack-light:#80d5ff; --pack-deep:#090e2b; --pack-glow:#5e6dffaa; }
    .grade-pack[data-tier="rainbow"] { --pack-main:#21142c; --pack-light:#fff3ff; --pack-deep:#0d0a15; --pack-glow:#ff74d9; }
    .grade-pack:hover,.grade-pack:focus-visible {
      transform: translateY(-4px); border-color: color-mix(in srgb,var(--pack-light),transparent 45%);
      outline: none; background: #ffffff08;
    }
    .primary:disabled,.grade-pack:disabled { opacity: .58; cursor: wait; }
    .grade-pack-wrap { position: relative; min-width: 0; }
    .grade-pack-wrap .grade-pack { width: 100%; height: 100%; }
    .custom-pack-delete {
      position: absolute; top: 38px; right: 8px; z-index: 3;
      display: grid; place-items: center; width: 30px; height: 30px;
      border: 1px solid #ff9a9a88; border-radius: 50%; color: #fff;
      background: #34151ddd; cursor: pointer; opacity: .9;
      transition: transform .2s,background .2s,opacity .2s;
    }
    .custom-pack-delete:hover { transform: scale(1.1); background: #8e2525; opacity: 1; }
    .custom-pack-delete:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
    .custom-pack-delete svg { width: 15px; height: 15px; fill: none; stroke: currentColor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.8; }
    .grade-pack:focus-visible { outline: 2px solid var(--pack-light); outline-offset: 2px; }
    .grade-pack .pack-subject { width: 100%; overflow: hidden; color: #e8edf7; font-size: 10px; font-weight: 800; text-overflow: ellipsis; white-space: nowrap; }
    .mini-pack {
      position: relative; display: grid; place-items: center; width: min(150px,100%);
      aspect-ratio: .66; overflow: hidden; border: 1px solid var(--pack-light); border-radius: 5px 5px 8px 8px;
      background:
        linear-gradient(90deg,var(--pack-light) 0 9px,transparent 9px),
        linear-gradient(135deg,transparent 0 40%,color-mix(in srgb,var(--pack-light),transparent 84%) 41% 58%,transparent 59%),
        linear-gradient(112deg,transparent 0 17%,#ffffff48 18% 19%,transparent 22%),
        repeating-linear-gradient(135deg,transparent 0 13px,#ffffff18 14px 15px),
        radial-gradient(ellipse at 68% 22%,color-mix(in srgb,var(--pack-light),transparent 72%),transparent 45%),
        linear-gradient(145deg,var(--pack-main),var(--pack-deep) 82%);
      box-shadow: 0 0 0 1px var(--pack-glow),0 8px 20px #000b,inset 0 0 24px var(--pack-glow);
      transition: transform .3s, filter .3s, box-shadow .3s;
    }
    .grade-pack:hover .mini-pack,.grade-pack:focus-visible .mini-pack { transform: translateY(-3px) scale(1.025); filter: brightness(1.13); }
    .mini-pack::before {
      position: absolute; inset: 5px 4px 5px 13px; z-index: 1; border: 1px solid color-mix(in srgb,var(--pack-light),transparent 42%);
      border-radius: 2px 2px 6px 6px; content: "";
      background:
        radial-gradient(ellipse at 50% 46%,color-mix(in srgb,var(--pack-light),transparent 84%),transparent 54%),
        linear-gradient(112deg,transparent 0 18%,#ffffff48 19% 20%,transparent 24%),
        repeating-linear-gradient(135deg,transparent 0 11px,#ffffff18 12px 13px);
    }
    .mini-pack::after {
      position: absolute; right: 3px; bottom: 4px; left: 13px; z-index: 3;
      content: "MAGISTER"; color: #ffffffed; font-size: 6px;
      font-weight: 900; letter-spacing: .1em; text-shadow: 0 1px 5px #000;
    }
    .mini-pack-spine {
      position: absolute; top: 0; bottom: 0; left: 0; z-index: 2;
      display: grid; place-items: center; width: 9px; border-right: 1px solid #ffffff80;
      color: #16151b; background: linear-gradient(180deg,var(--pack-light),var(--pack-main));
      font-size: 5px; font-weight: 1000; letter-spacing: .08em;
      writing-mode: vertical-rl; transform: rotate(180deg);
    }
    .mini-pack-emblem {
      position: absolute; top: 19%; left: 50%; z-index: 2;
      display: grid; place-items: center; width: 25%; max-width: 34px;
      aspect-ratio: 1; transform: translateX(-50%);
      clip-path: polygon(50% 0,100% 25%,82% 100%,18% 100%,0 25%);
      color: var(--pack-light);
      background: linear-gradient(145deg,#ffffff55,var(--pack-main) 55%,var(--pack-deep));
      filter: drop-shadow(0 2px 6px #000b);
    }
    .mini-pack-emblem::after {
      width: 52%; aspect-ratio: 1; content: "";
      border: 1px solid currentColor; transform: rotate(45deg);
    }
    .mini-pack-mark {
      position: absolute; top: 42%; left: 50%; z-index: 2;
      width: 80%; transform: translateX(-50%) skew(-12deg);
      color: var(--pack-light); font-size: clamp(23px,2.6vw,37px);
      font-style: italic; font-weight: 1000; letter-spacing: -.14em;
      padding-right: .14em; text-align: center;
      text-shadow: 0 2px 10px #000b,0 0 14px var(--pack-glow),1px 1px #fff8;
    }
    .mini-card {
      position: relative; display: grid; grid-template-rows: auto minmax(0,1fr) auto;
      justify-items: center; align-items: center; gap: 5px;
      width: min(150px,100%); aspect-ratio: .66; padding: 10px 8px;
      overflow: hidden; border: 1px solid var(--pack-light); border-radius: 8px;
      color: #f4f6ff;
      background:
        radial-gradient(ellipse at 50% 40%,color-mix(in srgb,var(--pack-light),transparent 82%),transparent 60%),
        repeating-linear-gradient(135deg,transparent 0 13px,#ffffff12 14px 15px),
        linear-gradient(145deg,var(--pack-main),var(--pack-deep) 82%);
      box-shadow: 0 0 0 1px var(--pack-glow),0 8px 20px #000b,inset 0 0 24px var(--pack-glow);
      transition: transform .3s, filter .3s, box-shadow .3s;
    }
    .mini-card::before {
      position: absolute; inset: 5px; content: ""; border: 1px solid color-mix(in srgb,var(--pack-light),transparent 42%);
      border-radius: 5px; background: linear-gradient(112deg,transparent 0 28%,#ffffff28 29% 30%,transparent 34%);
      pointer-events: none;
    }
    .grade-pack:hover .mini-card,.grade-pack:focus-visible .mini-card { transform: translateY(-3px) scale(1.025); filter: brightness(1.13); }
    .mini-card-rating,.mini-card-meme,.mini-card-title { position: relative; z-index: 1; }
    .mini-card-rating { color: var(--pack-light); font-size: clamp(22px,3vw,34px); font-weight: 1000; line-height: 1; text-shadow: 0 2px 8px #000b; }
    .mini-card-meme { display: block; width: auto; height: auto; max-width: 82%; max-height: 78px; object-fit: contain; }
    .mini-card-emblem { position: relative; z-index: 1; color: var(--pack-light); font-size: 42px; line-height: 1; text-shadow: 0 0 18px var(--pack-glow); }
    .mini-card-title { display: -webkit-box; max-width: 100%; overflow: hidden; color: #fff; font-size: 8px; font-weight: 900; line-height: 1.15; overflow-wrap: anywhere; text-align: center; text-overflow: ellipsis; text-transform: uppercase; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    .grade-pack[data-tier="rainbow"] .mini-card { background: linear-gradient(145deg,#120b2455,#120b2414 52%,#120b2466),conic-gradient(from 25deg at 50% 50%,#ff4e69,#ff9b43,#fff16a,#58ee90,#51d9ef,#8c73ff,#ee62d0,#ff4e69); }
    .grade-pack[data-tier="galaxy"] .mini-card { background: radial-gradient(circle at 73% 24%,#ffffff 0 1px,transparent 2px),radial-gradient(circle at 32% 32%,#c9eeff 0 1px,transparent 2px),radial-gradient(ellipse at 68% 22%,#436dff99,transparent 48%),linear-gradient(145deg,var(--pack-main),var(--pack-deep) 82%); }
    .grade-pack[data-tier="rainbow"] .mini-pack {
      background:
        linear-gradient(145deg,#120b2455,#120b2414 52%,#120b2466),
        conic-gradient(from 25deg at 50% 50%,#ff4e69,#ff9b43,#fff16a,#58ee90,#51d9ef,#8c73ff,#ee62d0,#ff4e69);
      background-size: 100% 100%,180% 180%;
      animation: rainbow-pack-shift 5s linear infinite;
    }
    .grade-pack[data-tier="gold-rare"] .mini-pack {
      background:
        linear-gradient(90deg,var(--pack-light) 0 9px,transparent 9px),
        linear-gradient(135deg,transparent 0 40%,#24e88766 41% 58%,transparent 59%),
        repeating-linear-gradient(45deg,transparent 0 14px,#ffffff14 15px 16px),
        linear-gradient(145deg,var(--pack-main),var(--pack-deep) 82%);
    }
    .grade-pack[data-tier="galaxy"] .mini-pack {
      background:
        linear-gradient(90deg,var(--pack-light) 0 9px,transparent 9px),
        linear-gradient(135deg,transparent 0 37%,#765bff88 38% 58%,transparent 59%),
        radial-gradient(circle at 73% 24%,#ffffff 0 1px,transparent 2px),
        radial-gradient(circle at 32% 32%,#c9eeff 0 1px,transparent 2px),
        radial-gradient(circle at 76% 74%,#c9eeff 0 1px,transparent 2px),
        radial-gradient(ellipse at 68% 22%,#436dff99,transparent 48%),
        linear-gradient(145deg,var(--pack-main),var(--pack-deep) 82%);
    }
    .grade-pack[data-tier="galaxy"] .mini-pack { box-shadow: 0 0 0 1px #80d5ff,0 0 18px #496bff99,0 8px 20px #000b; }
    .grade-pack[data-tier="rainbow"] { border-color: #ff9ee8aa; }
    .grade-pack[data-tier="rainbow"] .mini-pack { box-shadow: 0 0 0 2px #fff,0 0 16px #ff5ab8,0 0 32px #61dfff,0 12px 28px #0009; }
    @keyframes rainbow-pack-shift {
      to { background-position: center,180% 180%; }
    }
    .grade-pack.is-opening .mini-pack { animation: pack-shake .45s ease-in-out 2, pack-mini-flash .9s ease-in-out forwards; }
    @keyframes pack-mini-flash {
      60% { filter: brightness(1); }
      78% { filter: brightness(4); }
      100% { filter: brightness(.2); transform: scale(.85); }
    }
    .pack-callout { width: 100%; color: #f4f6ff; font-size: clamp(7px,2.1vw,9px); font-weight: 900; letter-spacing: .06em; overflow-wrap: anywhere; }
    .pack-state { width: 100%; overflow: hidden; color: #b9c9e6; font-size: 10px; text-overflow: ellipsis; white-space: nowrap; }
    .empty { color: #c1ccc4; }
    @media (max-width:600px) {
      .app { padding: 14px 12px 30px; }
      .close { position: fixed; top: 12px; right: 12px; background: #101912dd; }
      .home-header { margin-bottom: 18px; }
      .header-tools { width: 100%; justify-content: space-between; }
      .logbook-panel { top: 62px; right: 12px; }
      .pack-area { min-height: 440px; }
      .squad-pitch { min-height: 430px; gap: 5px; padding: 18px 7px; }
      .squad-row[data-line="attack"],.squad-row[data-line="midfield"] { width: 88%; }
      .squad-row[data-line="goalkeeper"] { width: 30%; }
      .lineup-player,.lineup-empty { width: clamp(52px,15vw,76px); }
      .lineup-rating { font-size: 15px; }
      .lineup-meme { max-height: 36px; }
      .pitch-markings { inset: 12px; }
      .stage-back { top: 10px; left: 10px; }
      .stage-logbook { top: 10px; right: 10px; }
      .pack { width: 184px; height: 276px; }
      .side-card { width: clamp(64px,18vw,95px); height: clamp(112px,28vw,155px); padding: 10px 8px; }
      .side-left { left: 3%; }
      .side-right { right: 3%; }
      .result { width: min(260px,100%); }
      .grades { grid-template-columns: repeat(3,minmax(0,1fr)); gap: 8px; }
      .mini-pack { width: 100%; }
    }
    @media (max-width:420px) {
      .grades { grid-template-columns: repeat(2,minmax(0,1fr)); }
    }
    @media (max-width:360px) {
      .side-card { display: none; }
      .squad-pitch { min-height: 390px; }
      .lineup-player,.lineup-empty { width: 48px; }
    }
    @media (max-height:520px) {
      .pack-area { min-height: 390px; }
      .result-area { padding: 16px 16px 8px; }
      .result { grid-template-rows: auto minmax(72px,1fr) auto auto auto; width: min(230px,100%); height: min(340px,100%); padding: 16px 12px 28px; gap: 5px; }
      .card-meme { max-width: min(72px,100%); max-height: min(106px,100%); }
      .card-info h2 { font-size: 14px; }
    }
    @media (prefers-reduced-motion: reduce) {
      *,*::before,*::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; scroll-behavior: auto !important; }
    }
  `;

  const host = document.createElement("div");
  host.id = ROOT_ID;
  const shadow = host.attachShadow({ mode: "closed" });
  const styleElement = document.createElement("style");
  styleElement.textContent = style;
  shadow.append(styleElement);
  document.documentElement.append(host);
  let selectedTheme = "stadion";
  let customMemes = {};
  function isValidCustomMemes(value) {
    return value !== null
      && typeof value === "object"
      && !Array.isArray(value)
      && Object.entries(value).every(([rating, dataUrl]) =>
        /^[1-9]$|^10$/.test(rating)
        && typeof dataUrl === "string"
        && dataUrl.length <= MAX_CUSTOM_MEME_DATA_URL_LENGTH
        && /^data:image\/(?:webp|png|jpeg);base64,[A-Za-z0-9+/]+={0,2}$/.test(dataUrl));
  }
  function getMemeRating(value) {
    const numericGrade = Number(String(value).trim().replace(",", "."));
    return Number.isFinite(numericGrade)
      ? Math.min(10, Math.max(1, Math.round(numericGrade)))
      : 0;
  }
  function getMemeUrl(value) {
    const rating = getMemeRating(value);
    if (!rating) return "";
    return customMemes[String(rating)] || MEME_ICON_URLS[rating - 1] || "";
  }
  function updateMemeImages() {
    for (const image of shadow.querySelectorAll("img[data-grade-rating]")) {
      image.src = getMemeUrl(image.dataset.gradeRating);
    }
  }
  if (extensionStorage) {
    extensionStorage.get([THEME_STORAGE_KEY, CUSTOM_MEMES_STORAGE_KEY]).then((stored) => {
      const theme = stored[THEME_STORAGE_KEY];
      if (THEMES.has(theme)) selectedTheme = theme;
      const savedMemes = stored[CUSTOM_MEMES_STORAGE_KEY];
      if (savedMemes !== undefined && !isValidCustomMemes(savedMemes)) {
        throw new TypeError("De opgeslagen custom memes hebben een ongeldig formaat.");
      }
      customMemes = savedMemes || {};
      const app = shadow.querySelector(".app");
      if (app) app.dataset.theme = selectedTheme;
      updateMemeImages();
    }).catch((error) => {
      console.error("[Magister Pack Club] Instellingen konden niet worden geladen:", error);
    });
  }
  extensionStorageChanges?.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    if (changes[THEME_STORAGE_KEY]) {
      const theme = changes[THEME_STORAGE_KEY].newValue;
      selectedTheme = THEMES.has(theme) ? theme : "stadion";
      const app = shadow.querySelector(".app");
      if (app) app.dataset.theme = selectedTheme;
    }
    if (changes[CUSTOM_MEMES_STORAGE_KEY]) {
      const savedMemes = changes[CUSTOM_MEMES_STORAGE_KEY].newValue;
      if (savedMemes !== undefined && !isValidCustomMemes(savedMemes)) {
        console.error("[Magister Pack Club] Nieuwe custom memes hebben een ongeldig formaat.");
        return;
      }
      customMemes = savedMemes || {};
      updateMemeImages();
    }
  });

  const gradePattern = /^(10(?:[.,]0)?|[1-9](?:[.,]\d{1,2})?|0?[.,]\d{1,2})\*?$/;
  const datePattern = /\b\d{1,2}[-‐‑‒–—/.]\d{1,2}[-‐‑‒–—/.]\d{2,4}\b/;
  const weightPattern = /\b(?:weging|gewicht)\s*:?\s*(\d+(?:[.,]\d+)?)\b/i;
  const normalize = (value) => value.replace(/\s+/g, " ").trim();

  function headerIndex(headers, pattern) {
    return headers.findIndex((header) => pattern.test(header));
  }

  function getCardTier(value) {
    const parsedGrade = Number(String(value).trim().replace(",", "."));
    const grade = Number.isFinite(parsedGrade) ? parsedGrade : 0;
    const tier = grade >= 10
      ? { id: "rainbow", packName: "RAINBOW" }
      : grade > 7
        ? { id: "galaxy", packName: "GALAXY" }
        : grade > 6
          ? { id: "gold-rare", packName: "RARE GOLD" }
          : grade >= 5
            ? { id: "gold", packName: "GOLD" }
            : grade >= 4
              ? { id: "silver", packName: "SILVER" }
              : { id: "bronze", packName: "BRONZE" };
    return tier;
  }

  function readGrades() {
    const grades = [];
    const seen = new Set();
    const rows = [...document.querySelectorAll(
      "tr, [role='row'], [role='listitem'], [class*='row'], [class*='Row']"
    )];

    for (const row of rows) {
      let cells = [...row.querySelectorAll(
        "th, td, [role='cell'], [role='gridcell'], [class*='cell'], [class*='Cell']"
      )];
      if (cells.length < 2) {
        cells = [...row.children];
      }
      cells = cells.filter((cell) => cell !== row && normalize(cell.textContent || ""));
      if (cells.length < 2) continue;

      const values = cells.map((cell) => normalize(cell.textContent || ""));
      const headers = [...(row.closest("table")?.querySelectorAll("thead tr:last-child th, thead tr:last-child td") || [])]
        .map((cell) => normalize(cell.textContent || "").toLowerCase());
      const gradeColumn = headerIndex(headers, /cijfer|resultaat|score|grade/);
      let gradeIndex = gradeColumn >= 0 ? gradeColumn : values.findIndex((value) => gradePattern.test(value));
      let gradeValue = values[gradeIndex] || "";
      if (gradeIndex < 0 || !gradePattern.test(gradeValue)) {
        const rowText = normalize(row.textContent || "").replace(datePattern, " ");
        const match = rowText.match(/(?<![\d/.\u2010-\u2015])(?:10(?:[.,]0)?|[1-9](?:[.,]\d{1,2})?|0?[.,]\d{1,2})\*?(?![\d/.\u2010-\u2015])/);
        if (!match) continue;
        const matchedValue = match[0];
        gradeValue = matchedValue;
        gradeIndex = values.findIndex((value) => value.includes(matchedValue));
        if (gradeIndex < 0) {
          values.push(matchedValue);
          gradeIndex = values.length - 1;
        }
      }
      if (!gradePattern.test(gradeValue) || datePattern.test(gradeValue)) continue;

      const subjectColumn = headerIndex(headers, /vak|subject|course/);
      const titleColumn = headerIndex(headers, /toets|omschrijving|onderdeel|assessment|title/);
      const dateColumn = headerIndex(headers, /datum|date/);
      const weightColumn = headerIndex(headers, /weging|gewicht|weight/);
      const usable = values.filter((value, index) => index !== gradeIndex && value && !gradePattern.test(value));
      const subject = values[subjectColumn] && subjectColumn !== gradeIndex
        ? values[subjectColumn]
        : usable[0] || "Onbekend vak";
      const title = values[titleColumn] && titleColumn !== gradeIndex
        ? values[titleColumn]
        : usable.find((value) => value !== subject && !datePattern.test(value)) || "Cijfer";
      const date = values[dateColumn] && dateColumn !== gradeIndex
        ? values[dateColumn]
        : values.find((value) => datePattern.test(value)) || "";
      const weightValue = values[weightColumn] && weightColumn !== gradeIndex
        ? values[weightColumn]
        : row.textContent.match(weightPattern)?.[1] || "";
      const weight = weightValue ? (/^\d+(?:[.,]\d+)?$/.test(weightValue) ? weightValue : weightValue.replace(/.*?(\d+(?:[.,]\d+)?).*/, "$1")) : "";
      const key = [subject, title, gradeValue, date].join("|").toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      grades.push({ subject, title, value: gradeValue.replace("*", "").replace(",", "."), date, weight });
    }
    return grades;
  }

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function openDashboard() {
    if (shadow.querySelector(".backdrop")) return;
    let magisterGrades = readGrades();
    let customGrades = [];
    let grades = [...magisterGrades, ...customGrades];
    const openedGradeKeys = new Set();
    const openedGradeOrder = [];
    const openedGrades = [];
    let openedGradeLoadComplete = false;
    let openedGradeStorageReady = false;
    let openedGradeStorageError = false;
    const gradeKey = (grade) => {
      const identity = grade.customId
        ? `custom|${grade.customId}`
        : [grade.subject, grade.title, grade.value, grade.date].join("|").toLocaleLowerCase("nl-NL");
      let hash = 0xcbf29ce484222325n;
      for (let index = 0; index < identity.length; index += 1) {
        hash ^= BigInt(identity.charCodeAt(index));
        hash = BigInt.asUintN(64, hash * 0x100000001b3n);
      }
      return hash.toString(16).padStart(16, "0");
    };
    const backdrop = element("div", "backdrop");
    const app = element("section", "app");
    app.dataset.theme = selectedTheme;
    app.setAttribute("role", "dialog");
    app.setAttribute("aria-modal", "true");
    app.setAttribute("aria-label", "Magister Cijfer Packs");

    const close = element("button", "close", "×");
    close.type = "button";
    close.setAttribute("aria-label", "Sluiten");
    let pageObserver;
    let refreshTimer;
    let revealTimer;
    let tunnelTimer;
    close.addEventListener("click", () => {
      pageObserver?.disconnect();
      window.clearTimeout(refreshTimer);
      window.clearTimeout(revealTimer);
      window.clearTimeout(tunnelTimer);
      backdrop.remove();
    });
    const topBar = element("div", "home-header");
    const brand = element("div", "brand");
    brand.append(element("span", "brand-mark", "✦"), element("span", "", "MAGISTER PACK CLUB"));
    const headerTools = element("div", "header-tools");
    const versionStatus = element("span", "version-status", APP_VERSION === "onbekend"
      ? "Versie onbekend · geladen"
      : `V${APP_VERSION} · geladen`);
    versionStatus.setAttribute("role", "status");
    versionStatus.setAttribute("aria-live", "polite");
    const logbookButton = element("button", "logbook-button", "Logboek");
    logbookButton.type = "button";
    logbookButton.setAttribute("aria-expanded", "false");
    logbookButton.setAttribute("aria-controls", "magister-pack-logbook");
    const stageLogbookButton = element("button", "stage-logbook",
      APP_VERSION === "onbekend" ? "Versie · Logboek" : `V${APP_VERSION} · Logboek`);
    stageLogbookButton.type = "button";
    stageLogbookButton.setAttribute("aria-expanded", "false");
    stageLogbookButton.setAttribute("aria-controls", "magister-pack-logbook");
    const versionControls = element("div", "version-controls");
    versionControls.append(versionStatus, logbookButton);
    headerTools.append(
      element("div", "home-meta", "JOUW CIJFERS. JOUW MOMENT."),
      versionControls
    );
    topBar.append(brand, headerTools);
    const logbookPanel = element("section", "logbook-panel");
    logbookPanel.id = "magister-pack-logbook";
    logbookPanel.hidden = true;
    logbookPanel.setAttribute("role", "dialog");
    logbookPanel.setAttribute("aria-labelledby", "magister-pack-logbook-title");
    const logbookHead = element("div", "logbook-head");
    const logbookTitle = element("h2", "", "LOGBOEK");
    logbookTitle.id = "magister-pack-logbook-title";
    const logbookClose = element("button", "logbook-close", "×");
    logbookClose.type = "button";
    logbookClose.setAttribute("aria-label", "Logboek sluiten");
    logbookHead.append(logbookTitle, logbookClose);
    const logbookSummary = element("p", "logbook-summary", "De nieuwste wijzigingen in Magister Pack Club.");
    const logbookList = element("ol", "logbook-list");
    const releaseNotes = [
      { version: "2.0.0", description: "Geopende cijferkaarten staan nu in een voetbalopstelling; pack-openingen gaan door een cinematische tunnel." },
      { version: "1.4.0", description: "Instellingen resetten, presets bewaren/delen/inladen en eigen memes per cijfer." },
      { version: "1.3.0", description: "Thema's kiezen via het menu van het extensie-icoon." },
      { version: "1.2.9", description: "Custom packs zijn nu ook met het prullenbakicoon te verwijderen." },
      { version: "1.2.8", description: "Creator Mode maakt custom demo-packs met eigen titel, categorie en cijfer." },
      { version: "1.2.7", description: "Geopende packs worden kaarten; Creator Mode maakt aparte lokale demo-packs." },
      { version: "1.2.6", description: "Geopende packs worden lokaal onthouden en veranderen in de bijbehorende cijferkaart." },
      { version: "1.2.5", description: "Links staat de laatst geopende kaart; rechts het volgende ongeopende pack." },
      { version: "1.2.4", description: "Zijkaarten tonen en openen de vorige/volgende cijfers; de datumregel blijft binnen de kaartcontour." },
      { version: "1.2.3", description: "Grotere memes, kaarttekst blijft binnen de rand en drie cutscenes voor cijfers <6, 6–<9 en 9+." },
      { version: "1.2.2", description: "Memes vergroot; speciale effecten lopen op per cijfer, met explosies en soms een cinematic." },
      { version: "1.2", description: "Tien vaste memes gekoppeld aan cijfers 1–10; dezelfde score krijgt steeds dezelfde meme." },
      { version: "1.0.11", description: "Meme groter en zonder rand; extra kattenfoto's toegevoegd." },
      { version: "1.0.10", description: "Dubbele kaart-randen verwijderd voor één strakke, doorlopende contour." },
      { version: "1.0.9", description: "Buitenlijn achter de tekst geplaatst en extra ruimte rond de onderste cijfergegevens." },
      { version: "1.0.8", description: "Duidelijke gekleurde buitenlijn rond de cijferkaart toegevoegd." },
      { version: "1.0.7", description: "Extra ruimte voor de kattenfoto voorkomt dat de onderkant wordt afgesneden." },
      { version: "1.0.6", description: "Kattenfoto wordt volledig getoond in de originele verhouding, zonder uitsnijden." },
      { version: "1.0.5", description: "Cijferkaart verkleind zodat deze volledig in het packscherm past." },
      { version: "1.0.4", description: "Kaart compacter gemaakt en de aangeleverde kattenmeme als icoon toegevoegd." },
      { version: "1.0.3", description: "Versie- en logboeklabels vereenvoudigd naar gewone witte tekst." },
      { version: "1.0.2", description: "Speler verwijderd uit de cijferkaart; vernieuwde teal-gouden kaart en versieknop op het packscherm." },
      { version: "1.0.1", description: "Versienummer en laadstatus toegevoegd, met een logboekvenster." },
      { version: "1.0.0", description: "Cijferpacks met brons-, zilver-, goud-, Galaxy- en Rainbow-tiers." }
    ];
    for (const note of releaseNotes) {
      const entry = element("li", "log-entry");
      entry.append(
        element("strong", "", `V${note.version}`),
        element("span", "", note.description)
      );
      logbookList.append(entry);
    }
    logbookPanel.append(logbookHead, logbookSummary, logbookList);
    let logbookTrigger = logbookButton;
    function openLogbook(trigger) {
      logbookTrigger = trigger;
      logbookPanel.hidden = false;
      logbookButton.setAttribute("aria-expanded", "true");
      stageLogbookButton.setAttribute("aria-expanded", "true");
      logbookClose.focus();
    }
    function closeLogbook() {
      logbookPanel.hidden = true;
      logbookButton.setAttribute("aria-expanded", "false");
      stageLogbookButton.setAttribute("aria-expanded", "false");
      logbookTrigger.focus();
    }
    logbookButton.addEventListener("click", () => {
      logbookPanel.hidden = !logbookPanel.hidden;
      if (logbookPanel.hidden) {
        closeLogbook();
      } else {
        openLogbook(logbookButton);
      }
    });
    stageLogbookButton.addEventListener("click", () => {
      if (logbookPanel.hidden) {
        openLogbook(stageLogbookButton);
      } else {
        closeLogbook();
      }
    });
    logbookClose.addEventListener("click", closeLogbook);
    const header = element("div", "home-intro");
    header.append(
      element("div", "eyebrow", "HET SEIZOEN BEGINT HIER"),
      element("h1", "", "Jouw cijfers. Jouw packs."),
      element("p", "sub", `${grades.length} ${grades.length === 1 ? "cijfer" : "cijfers"} klaar om te ontdekken`)
    );
    const actions = element("div", "actions");
    const openButton = element("button", "primary", "OPEN JE PACK  ↗");
    openButton.type = "button";
    openButton.disabled = true;
    const refreshButton = element("button", "secondary", "Cijfers opnieuw laden");
    refreshButton.type = "button";
    const creatorButton = element("button", "secondary", "Creator Mode");
    creatorButton.type = "button";
    creatorButton.disabled = true;
    creatorButton.setAttribute("aria-expanded", "false");
    creatorButton.setAttribute("aria-controls", "magister-pack-creator");
    actions.append(openButton, refreshButton, creatorButton);
    const notice = element("p", "notice", grades.length
      ? "Je cijfers worden niet verstuurd. De status van geopende packs wordt lokaal bewaard."
      : "Geen cijfers gevonden. Open in Magister de pagina met je cijfers en probeer opnieuw.");
    const creatorPanel = element("section", "creator-panel");
    creatorPanel.id = "magister-pack-creator";
    creatorPanel.hidden = true;
    creatorPanel.setAttribute("role", "dialog");
    creatorPanel.setAttribute("aria-labelledby", "magister-pack-creator-title");
    const creatorHead = element("div", "creator-head");
    const creatorTitle = element("h2", "", "CREATOR MODE");
    creatorTitle.id = "magister-pack-creator-title";
    const creatorClose = element("button", "logbook-close", "×");
    creatorClose.type = "button";
    creatorClose.setAttribute("aria-label", "Creator Mode sluiten");
    creatorHead.append(creatorTitle, creatorClose);
    const creatorCopy = element("p", "creator-copy",
      "Maak lokale demo-packs. Deze veranderen niets aan echte Magister-cijfers.");
    const creatorForm = element("form", "creator-form");
    const customTitleInput = element("input", "creator-input");
    customTitleInput.type = "text";
    customTitleInput.maxLength = 60;
    customTitleInput.required = true;
    customTitleInput.placeholder = "Bijvoorbeeld: TikTok challenge";
    const customSubjectInput = element("input", "creator-input");
    customSubjectInput.type = "text";
    customSubjectInput.maxLength = 32;
    customSubjectInput.required = true;
    customSubjectInput.value = "Custom";
    const customGradeInput = element("input", "creator-input");
    customGradeInput.type = "number";
    customGradeInput.min = "0";
    customGradeInput.max = "10";
    customGradeInput.step = "0.1";
    customGradeInput.required = true;
    customGradeInput.placeholder = "7.5";
    function creatorField(label, input) {
      const field = element("label", "creator-field");
      field.append(element("span", "", label), input);
      return field;
    }
    const creatorError = element("p", "creator-error");
    creatorError.setAttribute("role", "alert");
    const creatorSubmit = element("button", "primary creator-submit", "MAAK CUSTOM PACK");
    creatorSubmit.type = "submit";
    creatorForm.append(
      creatorField("Packtitel", customTitleInput),
      creatorField("Vak / categorie", customSubjectInput),
      creatorField("Cijfer (0–10)", customGradeInput),
      creatorError,
      creatorSubmit
    );
    creatorPanel.append(creatorHead, creatorCopy, creatorForm);
    creatorButton.addEventListener("click", () => {
      creatorPanel.hidden = false;
      creatorButton.setAttribute("aria-expanded", "true");
      customTitleInput.focus();
    });
    creatorClose.addEventListener("click", () => {
      creatorPanel.hidden = true;
      creatorButton.setAttribute("aria-expanded", "false");
      creatorButton.focus();
    });
    creatorForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const title = customTitleInput.value.trim();
      const subject = customSubjectInput.value.trim();
      const numericGrade = Number(customGradeInput.value.trim().replace(",", "."));
      if (!title || !subject || !Number.isFinite(numericGrade) || numericGrade < 0 || numericGrade > 10) {
        creatorError.textContent = "Vul een titel, categorie en geldig cijfer tussen 0 en 10 in.";
        return;
      }
      if (!openedGradeLoadComplete) {
        creatorError.textContent = "Wacht tot de packstatus is geladen.";
        return;
      }
      const customId = globalThis.crypto?.randomUUID?.()
        || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      creatorSubmit.disabled = true;
      customGrades.push({
        customId,
        isCustom: true,
        subject,
        title,
        value: numericGrade.toLocaleString("nl-NL", { maximumFractionDigits: 2 }),
        date: "",
        weight: ""
      });
      renderGrades();
      try {
        const saved = await saveLocalPackData();
        if (!saved) throw new Error("Lokale extensieopslag is niet beschikbaar.");
        creatorError.textContent = "";
        creatorPanel.hidden = true;
        creatorButton.setAttribute("aria-expanded", "false");
        creatorButton.focus();
        customTitleInput.value = "";
        customSubjectInput.value = "Custom";
        customGradeInput.value = "";
        notice.textContent = `Custom pack '${title}' toegevoegd.`;
      } catch (error) {
        console.error("[Magister Pack Club] Custom pack kon niet lokaal worden opgeslagen:", error);
        openedGradeStorageError = true;
        customTitleInput.value = "";
        customSubjectInput.value = "Custom";
        customGradeInput.value = "";
        creatorError.textContent = "Pack toegevoegd voor deze sessie, maar lokaal opslaan is mislukt.";
      } finally {
        creatorSubmit.disabled = false;
      }
    });
    const packArea = element("div", "pack-area");
    packArea.hidden = true;
    const backButton = element("button", "stage-back", "← TERUG NAAR PACKS");
    backButton.type = "button";
    backButton.addEventListener("click", () => {
      window.clearTimeout(revealTimer);
      window.clearTimeout(tunnelTimer);
      revealTimer = null;
      tunnelTimer = null;
      packArea.hidden = true;
      packArea.classList.remove("is-opening", "is-revealed", "is-tunneling");
      delete packArea.dataset.tier;
      delete packArea.dataset.scene;
      packTitle.textContent = "PACK";
      packHint.textContent = "ULTIMATE CIJFERS";
      pack.classList.remove("opening");
      resultArea.replaceChildren();
    });
    const lights = element("div", "stage-lights");
    lights.setAttribute("aria-hidden", "true");
    const stageFx = element("div", "stage-fx");
    stageFx.setAttribute("aria-hidden", "true");
    const sceneArt = element("div", "scene-art");
    sceneArt.setAttribute("aria-hidden", "true");
    sceneArt.append(
      element("span", "scene-platform"),
      element("span", "scene-jet scene-jet-left"),
      element("span", "scene-jet scene-jet-right")
    );
    stageFx.append(sceneArt);
    for (const x of [12, 22, 31, 39, 47, 54, 62, 70, 79, 88, 17, 28, 36, 44, 58, 67, 76, 84]) {
      const ember = element("i");
      ember.style.setProperty("--burst-x", `${x + Math.random() * 5}%`);
      ember.style.setProperty("--burst-y", `${62 + Math.random() * 34}%`);
      ember.style.setProperty("--ember-delay", `${Math.random() * 1.35}s`);
      ember.style.setProperty("--ember-duration", `${1.1 + Math.random() * 1.3}s`);
      ember.style.setProperty("--ember-drift", `${Math.round(Math.random() * 100 - 50)}px`);
      stageFx.append(ember);
    }
    for (const className of ["firework-one", "firework-two", "firework-three"]) {
      stageFx.append(element("span", `firework ${className}`));
    }
    for (const className of ["blast-one", "blast-two", "blast-three"]) {
      stageFx.append(element("span", `blast ${className}`));
    }
    stageFx.append(element("span", "cutscene-bars"));
    const tunnel = element("div", "tunnel");
    tunnel.setAttribute("aria-hidden", "true");
    const tunnelRays = element("div", "tunnel-rays");
    const tunnelRings = element("div", "tunnel-rings");
    for (let index = 0; index < 9; index += 1) {
      const ring = element("span", "tunnel-ring");
      ring.style.setProperty("--ring-width", `${22 + index * 2}%`);
      ring.style.setProperty("--ring-height", `${15 + index * 1.5}%`);
      ring.style.setProperty("--ring-delay", `${index * 0.12}s`);
      tunnelRings.append(ring);
    }
    tunnel.append(tunnelRays, tunnelRings);
    const leftCard = element("button", "side-card side-left");
    leftCard.type = "button";
    leftCard.hidden = true;
    const rightCard = element("button", "side-card side-right");
    rightCard.type = "button";
    rightCard.hidden = true;
    function renderSideCard(card, grade, state) {
      card.replaceChildren();
      if (!grade) {
        card.hidden = true;
        card.onclick = null;
        card.removeAttribute("aria-label");
        delete card.dataset.tier;
        card.classList.remove("is-opened", "is-sealed");
        return;
      }
      const tier = getCardTier(grade.value);
      const isOpened = state === "opened";
      card.hidden = false;
      card.dataset.tier = tier.id;
      card.classList.toggle("is-opened", isOpened);
      card.classList.toggle("is-sealed", !isOpened);
      card.setAttribute("aria-label", isOpened
        ? `Opnieuw openen: cijferkaart voor ${grade.subject}, cijfer ${grade.value}`
        : `Open ongeopend ${tier.packName.toLowerCase()} pack voor ${grade.subject}`);
      if (isOpened) {
        card.append(
          element("span", "side-state", `${openedGrades.length} GEOPEND`),
          element("strong", "side-rating", grade.value),
          element("span", "side-subject", grade.subject),
          element("span", "side-tier", `${tier.packName} KAART`)
        );
      } else {
        card.append(
          element("span", "side-pack-mark", "MAGISTER"),
          element("strong", "side-pack-title", `${tier.packName} PACK`),
          element("span", "side-pack-subject", grade.subject),
          element("span", "side-pack-hint", "NOG DICHT · OPEN MIJ")
        );
      }
      card.onclick = () => reveal(grade);
    }
    function updateSideCards(currentGrade) {
      const lastOpened = openedGrades[openedGrades.length - 1] || null;
      const currentKey = currentGrade ? gradeKey(currentGrade) : "";
      const nextUnopened = grades.find((grade) =>
        !openedGradeKeys.has(gradeKey(grade)) && gradeKey(grade) !== currentKey
      ) || null;
      renderSideCard(leftCard, lastOpened, "opened");
      renderSideCard(rightCard, nextUnopened, "sealed");
    }
    function syncOpenedGrades() {
      const currentGrades = new Map(grades.map((grade) => [gradeKey(grade), grade]));
      openedGrades.splice(
        0,
        openedGrades.length,
        ...openedGradeOrder.map((key) => currentGrades.get(key)).filter(Boolean)
      );
    }
    function getMemeIconUrl(grade) {
      return getMemeUrl(grade.value);
    }
    function markGradeOpened(grade) {
      const key = gradeKey(grade);
      openedGradeKeys.add(key);
      const previousKeyIndex = openedGradeOrder.indexOf(key);
      if (previousKeyIndex >= 0) openedGradeOrder.splice(previousKeyIndex, 1);
      openedGradeOrder.push(key);
      const previousIndex = openedGrades.findIndex((openedGrade) => gradeKey(openedGrade) === key);
      if (previousIndex >= 0) openedGrades.splice(previousIndex, 1);
      openedGrades.push(grade);
    }
    async function loadOpenedGradeKeys() {
      try {
        if (!extensionStorage) throw new Error("Lokale extensieopslag is niet beschikbaar.");
        const stored = await extensionStorage.get([OPENED_GRADES_STORAGE_KEY, CUSTOM_PACKS_STORAGE_KEY]);
        const savedKeys = stored[OPENED_GRADES_STORAGE_KEY];
        const savedCustomGrades = stored[CUSTOM_PACKS_STORAGE_KEY];
        if (savedKeys !== undefined
          && (!Array.isArray(savedKeys) || savedKeys.some((key) => typeof key !== "string"))) {
          throw new TypeError("De opgeslagen packstatus heeft een ongeldig formaat.");
        }
        if (savedCustomGrades !== undefined
          && (!Array.isArray(savedCustomGrades) || savedCustomGrades.some((grade) =>
            !grade || grade.isCustom !== true || typeof grade.customId !== "string"
            || typeof grade.title !== "string" || !grade.title.trim()
            || typeof grade.subject !== "string" || !grade.subject.trim()
            || !Number.isFinite(Number(String(grade.value).replace(",", ".")))
            || Number(String(grade.value).replace(",", ".")) < 0
            || Number(String(grade.value).replace(",", ".")) > 10))) {
          throw new TypeError("De opgeslagen custom packs hebben een ongeldig formaat.");
        }
        customGrades = savedCustomGrades || [];
        for (const key of savedKeys || []) {
          if (openedGradeKeys.has(key)) continue;
          openedGradeKeys.add(key);
          openedGradeOrder.push(key);
        }
        openedGradeLoadComplete = true;
        openedGradeStorageReady = true;
        renderGrades();
      } catch (error) {
        console.error("[Magister Pack Club] Opgeslagen packstatus kon niet worden geladen:", error);
        openedGradeStorageError = true;
        openedGradeLoadComplete = true;
        renderGrades();
      }
    }
    async function saveLocalPackData() {
      if (!openedGradeStorageReady) return false;
      await extensionStorage.set({
        [OPENED_GRADES_STORAGE_KEY]: openedGradeOrder,
        [CUSTOM_PACKS_STORAGE_KEY]: customGrades
      });
      return true;
    }
    const pack = element("button", "pack");
    pack.type = "button";
    pack.setAttribute("aria-label", "Open het cijferpack");
    const packFace = element("span", "pack-face");
    const packTitle = element("strong", "pack-title", "PACK");
    const packHint = element("span", "pack-hint", "ULTIMATE CIJFERS");
    packFace.append(
      element("span", "pack-mark", "MAGISTER"),
      packTitle,
      packHint
    );
    pack.append(packFace);
    const resultArea = element("div", "result-area");
    packArea.append(backButton, stageLogbookButton, lights, leftCard, rightCard, stageFx, tunnel, pack, resultArea);

    function showResult(grade) {
      resultArea.replaceChildren();
      const result = element("article", "result");
      const tier = getCardTier(grade.value);
      result.dataset.tier = tier.id;
      packArea.dataset.tier = tier.id;
      const cardOutline = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      cardOutline.setAttribute("class", "card-outline");
      cardOutline.setAttribute("viewBox", "0 0 100 100");
      cardOutline.setAttribute("preserveAspectRatio", "none");
      cardOutline.setAttribute("aria-hidden", "true");
      const outlinePath = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
      outlinePath.setAttribute("points", "1.2,8.2 12.1,7.2 20.1,4.2 39,4.2 50,0.8 61,4.2 79.9,4.2 87.9,7.2 98.8,8.2 98.8,87.8 94.7,93.2 50,98.8 5.3,93.2 1.2,87.8");
      outlinePath.setAttribute("fill", "none");
      outlinePath.setAttribute("stroke", "currentColor");
      outlinePath.setAttribute("stroke-width", "1.5");
      outlinePath.setAttribute("stroke-linejoin", "round");
      cardOutline.append(outlinePath);
      result.append(cardOutline);
      const cardRating = element("div", "card-rating");
      cardRating.append(
        element("span", "card-rating-label", "CIJFER"),
        element("strong", "", grade.value)
      );
      result.append(cardRating);
      const cardArt = element("div", "card-art");
      cardArt.setAttribute("aria-hidden", "true");
      const memeIconUrl = getMemeIconUrl(grade);
      if (!memeIconUrl) {
        console.error("[Magister Pack Club] Het cijfer kon niet aan een meme worden gekoppeld:", grade.value);
      }
      if (memeIconUrl) {
        const memeIcon = element("img", "card-meme");
        memeIcon.src = memeIconUrl;
        memeIcon.dataset.gradeRating = String(getMemeRating(grade.value));
        memeIcon.alt = "Kattenmeme";
        memeIcon.addEventListener("error", () => {
          console.error("[Magister Pack Club] Het meme-icoon kon niet uit de extensiebestanden worden geladen.");
          memeIcon.replaceWith(element("span", "card-crest", "✦"));
        });
        cardArt.append(memeIcon);
      } else {
        console.error("[Magister Pack Club] De extensie kon geen URL voor het meme-icoon maken.");
        cardArt.append(element("span", "card-crest", "✦"));
      }
      result.append(cardArt);
      const cardInfo = element("div", "card-info");
      cardInfo.append(element("h2", "", grade.title));
      result.append(cardInfo);
      result.append(element("div", "card-tier", `${tier.packName} PACK`));
      const stats = [["VAK", grade.subject]];
      if (grade.date) stats.push(["DATUM", grade.date]);
      if (grade.weight) stats.push(["WEGING", grade.weight]);
      if (stats.length) {
        const details = element("div", "card-details");
        for (const [label, value] of stats) {
          const stat = element("div", "card-stat");
          stat.append(element("b", "", label), element("strong", "", value));
          details.append(stat);
        }
        result.append(details);
      }
      const sparkles = element("div", "sparkles");
      sparkles.setAttribute("aria-hidden", "true");
      for (let index = 0; index < 18; index += 1) {
        const sparkle = element("i");
        sparkle.style.setProperty("--spark-x", `${8 + Math.random() * 84}%`);
        sparkle.style.setProperty("--spark-y", `${8 + Math.random() * 84}%`);
        sparkle.style.setProperty("--spark-size", `${2 + Math.random() * 4}px`);
        sparkle.style.setProperty("--spark-delay", `${Math.random() * 0.9}s`);
        sparkles.append(sparkle);
      }
      result.append(sparkles);
      resultArea.append(result);
      packArea.classList.remove("is-opening", "is-tunneling");
      packArea.classList.add("is-revealed");
    }

    function reveal(selectedGrade) {
      if (packArea.classList.contains("is-opening")) return;
      if (!openedGradeLoadComplete) {
        notice.textContent = "De opgeslagen packstatus wordt geladen. Probeer het zo opnieuw.";
        return;
      }
      if (!grades.length) {
        notice.textContent = "Er zijn nog geen cijfers om te pack-openen. Ga naar je Magister-cijferpagina en laad opnieuw.";
        return;
      }
      const unopenedGrades = grades.filter((grade) => !openedGradeKeys.has(gradeKey(grade)));
      const availableGrades = unopenedGrades.length ? unopenedGrades : grades;
      const gradeToReveal = selectedGrade || availableGrades[Math.floor(Math.random() * availableGrades.length)];
      const tier = getCardTier(gradeToReveal.value);
      window.clearTimeout(revealTimer);
      window.clearTimeout(tunnelTimer);
      revealTimer = null;
      tunnelTimer = null;
      updateSideCards(gradeToReveal);
      packArea.hidden = false;
      packArea.dataset.tier = tier.id;
      const sceneGrade = Number(String(gradeToReveal.value).trim().replace(",", "."));
      if (!Number.isFinite(sceneGrade)) {
        console.error("[Magister Pack Club] Het cijfer kon niet aan een openingsscène worden gekoppeld:", gradeToReveal.value);
      }
      packArea.dataset.scene = sceneGrade >= 9 ? "high" : sceneGrade >= 6 ? "mid" : "low";
      const blastAnchors = [[24, 45], [76, 39], [50, 24]];
      for (const [index, blast] of [...stageFx.querySelectorAll(".blast")].entries()) {
        const [anchorX, anchorY] = blastAnchors[index];
        blast.style.setProperty("--blast-x", `${Math.round(anchorX + (Math.random() - .5) * 14)}%`);
        blast.style.setProperty("--blast-y", `${Math.round(anchorY + (Math.random() - .5) * 12)}%`);
      }
      packTitle.textContent = `${tier.packName} PACK`;
      packHint.textContent = `CIJFER ${gradeToReveal.value}`;
      packArea.scrollIntoView({ behavior: "smooth", block: "center" });
      resultArea.replaceChildren();
      packArea.classList.remove("is-revealed", "is-tunneling");
      packArea.classList.add("is-opening");
      pack.classList.remove("opening");
      void pack.offsetWidth;
      pack.classList.add("opening");
      notice.textContent = "De tunnel gaat open...";
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reducedMotion) {
        tunnelTimer = window.setTimeout(() => {
          tunnelTimer = null;
          if (!packArea.hidden) {
            packArea.classList.add("is-tunneling");
            notice.textContent = "Door de tunnel... wie zit er in je pack?";
          }
        }, 650);
      }
      revealTimer = window.setTimeout(async () => {
        revealTimer = null;
        showResult(gradeToReveal);
        markGradeOpened(gradeToReveal);
        renderGrades();
        try {
          const wasSaved = await saveLocalPackData();
          if (wasSaved) openedGradeStorageError = false;
          notice.textContent = wasSaved
            ? `${gradeToReveal.subject} pack geopend en opgeslagen!`
            : `${gradeToReveal.subject} pack geopend; voortgang wordt alleen deze sessie onthouden.`;
        } catch (error) {
          console.error("[Magister Pack Club] Opgeslagen packstatus kon niet worden bijgewerkt:", error);
          openedGradeStorageError = true;
          notice.textContent = `${gradeToReveal.subject} pack geopend, maar de voortgang kon niet worden opgeslagen.`;
        }
      }, reducedMotion ? 50 : 3400);
    }

    openButton.addEventListener("click", () => reveal());
    pack.addEventListener("click", () => reveal());
    refreshButton.addEventListener("click", () => {
      pageObserver?.disconnect();
      window.clearTimeout(refreshTimer);
      window.clearTimeout(revealTimer);
      window.clearTimeout(tunnelTimer);
      backdrop.remove();
      openDashboard();
    });

    const listTitle = element("h2", "section-title");
    const listLabel = element("span", "", "JOUW PACKS & KAARTEN");
    const packCount = element("small");
    listTitle.append(listLabel, packCount);
    const squadSection = element("section", "squad-section");
    const squadTitle = element("h2", "section-title");
    const squadLabel = element("span", "", "MIJN OPSTELLING");
    const squadCount = element("small", "", "0/11 kaarten in je team");
    squadTitle.append(squadLabel, squadCount);
    const squadPitch = element("div", "squad-pitch");
    squadPitch.setAttribute("role", "group");
    squadPitch.setAttribute("aria-label", "Voetbalopstelling van je geopende packs");
    const pitchMarkings = element("div", "pitch-markings");
    pitchMarkings.setAttribute("aria-hidden", "true");
    pitchMarkings.append(element("span", "pitch-box pitch-box-top"), element("span", "pitch-box pitch-box-bottom"));
    const squadLinks = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    squadLinks.setAttribute("class", "squad-links");
    squadLinks.setAttribute("viewBox", "0 0 1000 500");
    squadLinks.setAttribute("preserveAspectRatio", "none");
    squadLinks.setAttribute("aria-hidden", "true");
    for (const pathData of [
      "M200 86L200 205M500 86L500 205M800 86L800 205",
      "M200 205L140 330M200 205L380 330M500 205L380 330M500 205L620 330M800 205L620 330M800 205L860 330",
      "M140 330L500 440M380 330L500 440M620 330L500 440M860 330L500 440"
    ]) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", pathData);
      squadLinks.append(path);
    }
    const squadRows = [
      { line: "attack", positions: ["LW", "ST", "RW"] },
      { line: "midfield", positions: ["CM", "CAM", "CM"] },
      { line: "defence", positions: ["LB", "CB", "CB", "RB"] },
      { line: "goalkeeper", positions: ["GK"] }
    ].map(({ line }) => {
      const row = element("div", "squad-row");
      row.dataset.line = line;
      return row;
    });
    const squadBench = element("div", "squad-bench");
    squadPitch.append(pitchMarkings, squadLinks, ...squadRows);
    squadSection.append(squadTitle, squadPitch, squadBench);
    const list = element("div", "grades");
    function createLineupPlayer(grade, position) {
      const tier = getCardTier(grade.value);
      const button = element("button", "lineup-player");
      button.type = "button";
      button.setAttribute("aria-label", `Heropen: ${grade.subject} cijfer ${grade.value}, positie ${position}`);
      const card = element("span", "lineup-card");
      card.dataset.tier = tier.id;
      card.append(element("strong", "lineup-rating", grade.value));
      const memeUrl = getMemeIconUrl(grade);
      if (memeUrl) {
        const image = element("img", "lineup-meme");
        image.src = memeUrl;
        image.alt = "";
        image.addEventListener("error", () => {
          console.error("[Magister Pack Club] Meme op de opstellingskaart kon niet worden geladen.");
          image.replaceWith(element("span", "lineup-emblem", "✦"));
        });
        card.append(image);
      } else {
        card.append(element("span", "lineup-emblem", "✦"));
      }
      card.append(element("span", "lineup-subject", grade.subject));
      button.append(card, element("span", "lineup-position", position));
      button.addEventListener("click", () => reveal(grade));
      return button;
    }
    function renderSquad() {
      const lineupGrades = [...openedGrades].sort(
        (left, right) => Number(String(right.value).replace(",", ".")) - Number(String(left.value).replace(",", "."))
      );
      squadCount.textContent = `${Math.min(lineupGrades.length, 11)}/11 kaarten in je team`;
      let gradeIndex = 0;
      for (const [rowIndex, row] of squadRows.entries()) {
        row.replaceChildren();
        const positions = [
          ["LW", "ST", "RW"],
          ["CM", "CAM", "CM"],
          ["LB", "CB", "CB", "RB"],
          ["GK"]
        ][rowIndex];
        for (const position of positions) {
          const grade = lineupGrades[gradeIndex++];
          if (grade) {
            row.append(createLineupPlayer(grade, position));
          } else {
            const emptySlot = element("div", "lineup-empty");
            emptySlot.append(element("strong", "", "+"), element("span", "", position));
            row.append(emptySlot);
          }
        }
      }
      squadBench.replaceChildren();
      lineupGrades.slice(11).forEach((grade, index) => {
        squadBench.append(createLineupPlayer(grade, `RES ${index + 1}`));
      });
    }
    function renderGrades() {
      magisterGrades = readGrades();
      grades = [...magisterGrades, ...customGrades];
      syncOpenedGrades();
      renderSquad();
      const openedCount = grades.filter((grade) => openedGradeKeys.has(gradeKey(grade))).length;
      const unopenedCount = grades.length - openedCount;
      const unopenedLabel = `${unopenedCount} ${unopenedCount === 1 ? "pack" : "packs"} dicht`;
      const openedLabel = `${openedCount} ${openedCount === 1 ? "kaart" : "kaarten"} geopend`;
      header.querySelector(".sub").textContent = `${unopenedLabel} · ${openedLabel}`;
      packCount.textContent = `${unopenedLabel} · ${openedLabel}`;
      openButton.disabled = !openedGradeLoadComplete;
      creatorButton.disabled = !openedGradeLoadComplete;
      notice.textContent = !grades.length
        ? "Cijfers nog niet gevonden. Laat Magister laden of klik op Cijfers opnieuw laden."
        : !openedGradeLoadComplete
          ? "Opgeslagen packstatus laden..."
          : openedGradeStorageError
            ? "Packvoortgang lokaal opslaan lukt niet; geopende kaarten blijven deze sessie zichtbaar."
          : openedGradeStorageReady
            ? "Alleen de openstatus wordt lokaal bewaard; je cijfers worden niet verstuurd."
            : "Packvoortgang wordt alleen deze sessie onthouden.";
      list.replaceChildren();
      if (!grades.length) {
        list.append(element("p", "empty", "De cijfers verschijnen automatisch zodra Magister ze heeft geladen."));
        updateSideCards();
        return;
      }
      for (const grade of grades) {
        const tier = getCardTier(grade.value);
        const key = gradeKey(grade);
        const isOpened = openedGradeKeys.has(key);
        const card = element("button", "grade-pack");
        card.type = "button";
        card.disabled = !openedGradeLoadComplete;
        card.dataset.tier = tier.id;
        card.classList.toggle("is-opened", isOpened);
        card.setAttribute("aria-label", isOpened
          ? `Heropen de ${tier.packName.toLowerCase()} kaart voor ${grade.subject}, cijfer ${grade.value}`
          : grade.isCustom
            ? `Open custom pack '${grade.title}' voor ${grade.subject}`
            : `Open het gesloten ${tier.packName.toLowerCase()} pack voor ${grade.subject}`);
        card.append(element("span", "pack-subject", grade.isCustom ? grade.title : grade.subject));
        if (isOpened) {
          const miniCard = element("span", "mini-card");
          miniCard.append(element("strong", "mini-card-rating", grade.value));
          const memeIconUrl = getMemeIconUrl(grade);
          if (memeIconUrl) {
            const memeIcon = element("img", "mini-card-meme");
            memeIcon.src = memeIconUrl;
            memeIcon.dataset.gradeRating = String(getMemeRating(grade.value));
            memeIcon.alt = "";
            memeIcon.addEventListener("error", () => {
              console.error("[Magister Pack Club] Het meme-icoon voor de geopende kaart kon niet worden geladen.");
              memeIcon.replaceWith(element("span", "mini-card-emblem", "✦"));
            });
            miniCard.append(memeIcon);
          } else {
            miniCard.append(element("span", "mini-card-emblem", "✦"));
          }
          miniCard.append(element("span", "mini-card-title", grade.title));
          card.append(
            miniCard,
            element("span", "pack-callout", `${grade.isCustom ? "CUSTOM " : ""}${tier.packName} KAART`),
            element("span", "pack-state", "GEOPEND")
          );
        } else {
          const miniPack = element("span", "mini-pack");
          miniPack.append(
            element("span", "mini-pack-spine", "MAGISTER"),
            element("span", "mini-pack-emblem"),
            element("span", "mini-pack-mark", "MP")
          );
          card.append(
            miniPack,
            element("span", "pack-callout", `${grade.isCustom ? "CUSTOM " : ""}${tier.packName} PACK`),
            element("span", "pack-state", "NOG DICHT")
          );
        }
        card.addEventListener("click", () => {
          if (!openedGradeLoadComplete) return;
          card.classList.add("is-opening");
          window.setTimeout(
            () => reveal(grade),
            window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 450
          );
        });
        if (grade.isCustom) {
          const cardWrap = element("div", "grade-pack-wrap");
          const deleteButton = element("button", "custom-pack-delete");
          deleteButton.type = "button";
          deleteButton.setAttribute("aria-label", `Verwijder custom pack ${grade.title}`);
          deleteButton.title = "Verwijder custom pack";
          const trashIcon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          trashIcon.setAttribute("viewBox", "0 0 24 24");
          trashIcon.setAttribute("aria-hidden", "true");
          const trashPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
          trashPath.setAttribute("d", "M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3");
          trashIcon.append(trashPath);
          deleteButton.append(trashIcon);
          deleteButton.addEventListener("click", async (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (!window.confirm(`Custom pack '${grade.title}' verwijderen?`)) return;
            const customIndex = customGrades.indexOf(grade);
            if (customIndex < 0) return;
            const key = gradeKey(grade);
            const wasOpened = openedGradeKeys.has(key);
            const keyOrderIndex = openedGradeOrder.indexOf(key);
            customGrades.splice(customIndex, 1);
            openedGradeKeys.delete(key);
            if (keyOrderIndex >= 0) openedGradeOrder.splice(keyOrderIndex, 1);
            renderGrades();
            try {
              const saved = await saveLocalPackData();
              if (!saved) {
                openedGradeStorageError = true;
                notice.textContent = `Custom pack '${grade.title}' verwijderd voor deze sessie; opslaan is niet beschikbaar.`;
                return;
              }
              openedGradeStorageError = false;
              notice.textContent = `Custom pack '${grade.title}' verwijderd.`;
            } catch (error) {
              console.error("[Magister Pack Club] Custom pack kon niet worden verwijderd:", error);
              customGrades.splice(customIndex, 0, grade);
              if (wasOpened) {
                openedGradeKeys.add(key);
                const restoreIndex = keyOrderIndex < 0
                  ? openedGradeOrder.length
                  : Math.min(keyOrderIndex, openedGradeOrder.length);
                openedGradeOrder.splice(restoreIndex, 0, key);
              }
              openedGradeStorageError = true;
              renderGrades();
              notice.textContent = `Custom pack '${grade.title}' kon niet worden verwijderd.`;
            }
          });
          cardWrap.append(card, deleteButton);
          list.append(cardWrap);
        } else {
          list.append(card);
        }
      }
      updateSideCards();
    }
    renderGrades();
    void loadOpenedGradeKeys();

    app.append(close, topBar, logbookPanel, creatorPanel, header, actions, notice, packArea, squadSection, listTitle, list);
    backdrop.append(app);
    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) {
        pageObserver?.disconnect();
        window.clearTimeout(refreshTimer);
        window.clearTimeout(revealTimer);
        window.clearTimeout(tunnelTimer);
        backdrop.remove();
      }
    });
    shadow.append(backdrop);
    pageObserver = new MutationObserver(() => {
      window.clearTimeout(refreshTimer);
      refreshTimer = window.setTimeout(() => {
        const previousCount = grades.length;
        const previousValues = grades.map((grade) => `${grade.subject}|${grade.title}|${grade.value}`).join(";");
        renderGrades();
        const currentValues = grades.map((grade) => `${grade.subject}|${grade.title}|${grade.value}`).join(";");
        if (grades.length !== previousCount || currentValues !== previousValues) {
          resultArea.replaceChildren();
        }
      }, 500);
    });
    pageObserver.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    close.focus();
  }

  document.addEventListener("click", (event) => {
    const path = event.composedPath();
    if (path.includes(host)) return;

    const cijfersControl = path.find((node) => {
      if (!(node instanceof Element) || !node.matches("a, button, [role='button'], [role='link'], [role='menuitem'], [role='tab']")) return false;
      const label = normalize(node.innerText || node.getAttribute("aria-label") || node.textContent || "")
        .toLocaleLowerCase("nl-NL");
      return /^cijfers(?:\s*[-–—:]|$)/i.test(label);
    });
    if (!cijfersControl) return;

    const requestedAt = String(Date.now());
    sessionStorage.setItem(AUTO_OPEN_KEY, requestedAt);
    window.setTimeout(() => {
      if (sessionStorage.getItem(AUTO_OPEN_KEY) !== requestedAt) return;
      sessionStorage.removeItem(AUTO_OPEN_KEY);
      openDashboard();
    }, 1000);
  }, true);

  let routeOpenTimer;
  function openOnGradesRoute() {
    window.clearTimeout(routeOpenTimer);
    if (!isGradesRoute()) return;
    routeOpenTimer = window.setTimeout(openDashboard, 300);
  }
  window.addEventListener("hashchange", openOnGradesRoute);
  window.addEventListener("popstate", openOnGradesRoute);
  openOnGradesRoute();

  const observer = new MutationObserver(() => {
    if (!document.documentElement.contains(host)) document.documentElement.append(host);
  });
  observer.observe(document.documentElement, { childList: true });
})();
